import os
import re
import shutil
from contextlib import closing
from hashlib import sha256

from config.settings import ROOT
from core.models import now

VERSION = "0.3.8"
SOURCE_DIRS = ("ai","app","backtesting","collectors","config","core","database",
               "indicators","providers","risk","simulation","strategies")


def build_info(store, assets, network_context="미지정"):
    build = sha256()
    sources = [p for directory in SOURCE_DIRS for p in (ROOT/directory).glob("*.py")]
    for path in sorted(sources):
        build.update(path.relative_to(ROOT).as_posix().encode())
        build.update(path.read_bytes())
    for url,data in sorted(assets.items()):
        build.update(url.encode())
        build.update(data)
    ui = re.search(rb'const APP_VERSION = "([^"]+)"',assets["/app.js"])
    with closing(store.connect()) as conn:
        schema=conn.execute("PRAGMA user_version").fetchone()[0]
    return {"version":VERSION,"dashboard_version":ui[1].decode() if ui else None,"schema_version":schema,
            "build":build.hexdigest()[:16],"pid":os.getpid(),"started_at":now(),"network_context":network_context}


def metrics(store, resources, runtime):
    stamp=now()
    counts={r["status"]:r["n"] for r in store.query("SELECT status,COUNT(*) n FROM jobs GROUP BY status")}
    disk=store.path.parent
    wal=store.path.with_name(store.path.name+"-wal")
    db_bytes=sum(p.stat().st_size for p in (store.path,wal) if p.exists())
    row=resources.status() | {"at":stamp,"build":runtime["build"],"run_started_at":runtime["started_at"],
        "db_bytes":db_bytes,"disk_free":shutil.disk_usage(disk).free,"pending":counts.get("대기",0),
        "running":counts.get("실행",0),"completed":counts.get("완료",0),"failed":counts.get("오류",0)}
    row["notifications"]={item["status"]:item["n"] for item in
                          store.query("SELECT status,COUNT(*) n FROM notifications GROUP BY status")}
    row["error_occurrences"]=store.query("""SELECT COALESCE(SUM(json_extract(body,'$.occurrences')),0) n
        FROM records WHERE kind='diagnostic'""")[0]["n"]
    row["db_lock_logs"]=store.query("""SELECT COUNT(*) n FROM events WHERE time>=?
        AND (lower(message) LIKE '%locked%' OR message LIKE '%잠금%')""",(runtime["started_at"],))[0]["n"]
    row["oldest_pending"]=store.query("SELECT MIN(created) at FROM jobs WHERE status='대기'")[0]["at"]
    row["last_job_completion"]=store.query("SELECT MAX(updated) at FROM jobs WHERE status='완료'")[0]["at"]
    store.put("runtime_metrics",stamp,row)
    return row
