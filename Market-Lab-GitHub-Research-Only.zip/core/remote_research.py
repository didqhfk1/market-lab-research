"""Import and verify bounded, historical public-data research runs."""

from datetime import UTC, datetime
from hashlib import sha256
import hmac
import json
import re
from urllib.parse import urlsplit

from database.learning import Learning, digest
from providers.http import fetch_json

WORKFLOW = "public-research.yml"
SCHEMA = 1
PROTOCOL = "historical-exit-comparison-v1"
KIND = "remote_public_research"
METRICS = {"windows":32,"bars":4608,"missing_bars":4608,"pairs":32,"fixed_exits":32,
           "unlimited_exits":32,"compute_ms":300000,"cpu_ms":300000}
HEX64 = re.compile(r"[a-f0-9]{64}")
HEX40 = re.compile(r"[a-f0-9]{40}")
RUN_PATH = re.compile(r"/([A-Za-z0-9-]{1,39})/([A-Za-z0-9_.-]{1,100})/actions/runs/([1-9][0-9]{0,19})")


def fingerprint(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()


def checked_report(report):
    if not isinstance(report,dict) or set(report)!={"schema","protocol","input_sha256","result_sha256","metrics",
                                                       "commit","attempt","checksum"}:
        raise ValueError("이 연구의 JSON 결과 전문을 붙여넣으세요.")
    if type(report["schema"]) is not int or report["schema"]!=SCHEMA or report["protocol"]!=PROTOCOL:
        raise ValueError("이 버전에서 지원하는 공개 연구 결과가 아닙니다.")
    if any(not isinstance(report[k],str) or not HEX64.fullmatch(report[k])
           for k in ("input_sha256","result_sha256","checksum")):
        raise ValueError("보고서 해시 형식을 확인하세요.")
    commit=report["commit"]
    if not isinstance(commit,str) or not HEX40.fullmatch(commit) or type(report["attempt"]) is not int or report["attempt"]<1:
        raise ValueError("실행 버전 또는 시도 번호를 확인하세요.")
    metrics=report["metrics"]
    if not isinstance(metrics,dict) or metrics.keys()!=METRICS.keys() or any(
            type(value) is not int or not 0<=value<=METRICS[key] for key,value in metrics.items()):
        raise ValueError("보고서의 수치 형식과 범위를 확인하세요.")
    if (not 0<metrics["pairs"]<=metrics["windows"] or metrics["bars"]+metrics["missing_bars"]!=144*metrics["windows"]
            or max(metrics["fixed_exits"],metrics["unlimited_exits"])>metrics["pairs"]):
        raise ValueError("봉 수, 비교 표본 또는 청산 수가 맞지 않습니다.")
    payload={k:v for k,v in report.items() if k!="checksum"}
    if not hmac.compare_digest(fingerprint(payload),report["checksum"]):
        raise ValueError("보고서 내용이 실행 결과의 체크섬과 일치하지 않습니다.")
    return payload


def import_github(store, url, report, *, fetch=fetch_json):
    clean=checked_report(report)
    if not isinstance(url,str) or len(url)>210:
        raise ValueError("GitHub 실행 결과 주소를 확인하세요.")
    parts=urlsplit(url)
    match=RUN_PATH.fullmatch(parts.path)
    if (parts.scheme!="https" or parts.netloc!="github.com" or parts.query or parts.fragment or
            not match or match[2] in (".","..")):
        raise ValueError("공개 GitHub Actions 실행 결과 주소를 입력하세요.")
    owner,repo,run=match.groups()
    ident="github-public-study-"+digest([owner.lower(),repo.lower(),run,clean["attempt"]])[:36]
    history=Learning(store)
    previous=history.read(ident)
    if previous:
        if previous["checksum"]!=report["checksum"]:
            raise ValueError("같은 실행의 기존 결과와 체크섬이 다릅니다.")
        return previous
    if not store.charge("github-public-study:"+datetime.now(UTC).date().isoformat(),24):
        raise ValueError("공개 GitHub 확인의 일일 상한에 도달했습니다.")
    metadata=fetch(f"https://api.github.com/repos/{owner}/{repo}/actions/runs/{run}",timeout=5,max_bytes=160000)
    if not isinstance(metadata,dict):
        raise ValueError("GitHub 응답 형식을 확인하세요.")
    repository=metadata.get("repository")
    if not isinstance(repository,dict) or repository.get("private") is not False:
        raise ValueError("무료 표준 러너용 공개 저장소 실행만 확인합니다.")
    if (str(repository.get("full_name","")).lower()!=f"{owner}/{repo}".lower() or str(metadata.get("id"))!=run
            or str(metadata.get("path","")).partition("@")[0]!=".github/workflows/"+WORKFLOW
            or metadata.get("event")!="workflow_dispatch"
            or metadata.get("status")!="completed" or metadata.get("conclusion")!="success"
            or metadata.get("head_sha")!=clean["commit"] or metadata.get("run_attempt")!=clean["attempt"]):
        raise ValueError("공개 연구 워크플로 성공 내역과 결과의 실행 버전이 일치하지 않습니다.")
    payload={"url":url,"report":clean,"checksum":report["checksum"],"verified_run":True,
             "data_validation":"실행 메타데이터 확인 · 사용자가 가져온 결과의 체크섬 일치",
             "execution_policy":"별도 역사 연구 · 운영 규칙 및 원장 미반영"}
    history.append(KIND,ident,"",payload)
    return history.read(ident)


def recent(store):
    return Learning(store).items(KIND,limit=15)
