from dataclasses import asdict, dataclass
from datetime import UTC, datetime
import math
from urllib.parse import urlsplit

LIVE = "실시간 스냅샷"
DELAYED = "지연 · 일별"
HISTORY = "과거"
TEST = "테스트"


def now():
    return datetime.now(UTC).isoformat(timespec="seconds")


def timestamp(value):
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        raise ValueError("시각에 UTC 오프셋이 필요합니다.")
    return parsed.astimezone(UTC).isoformat(timespec="seconds")


def link(value):
    parts = urlsplit(value)
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password:
        raise ValueError("HTTPS 출처 URL이 필요합니다.")
    if any(ord(char) <= 32 for char in value):
        raise ValueError("출처 URL의 공백을 확인하세요.")
    return value


def number(value, minimum=0):
    if type(value) is bool:
        raise ValueError("잘못된 숫자입니다.")
    val = float(value)
    if not math.isfinite(val) or not minimum <= val <= 10**15:
        raise ValueError("숫자가 유효 범위를 벗어났습니다.")
    return val


@dataclass(frozen=True)
class Asset:
    id: str
    region: str
    symbol: str
    name: str
    exchange: str
    currency: str
    kind: str
    provider: str
    state: str = "확인 필요"
    cik: str = ""


@dataclass(frozen=True)
class Bar:
    time: str
    open: float
    high: float
    low: float
    close: float
    volume: float | None
    turnover: float | None = None

    @classmethod
    def make(cls, time, opening, high, low, close, volume=None, turnover=None):
        o, h, l, c = [number(v, 1e-12) for v in (opening, high, low, close)]
        if l > min(o, c) or h < max(o, c):
            raise ValueError("OHLC 가격 범위가 일치하지 않습니다.")
        return cls(timestamp(time), o, h, l, c,
                   None if volume is None else number(volume),
                   None if turnover is None else number(turnover))

    def json(self):
        return asdict(self)
