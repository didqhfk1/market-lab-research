from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
import re

from core.models import LIVE

ACTIVE = ("목록 등재","거래 가능")


def decimal(value, minimum="0", maximum="1000000000000000"):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError("유효한 숫자를 입력하세요.") from None
    if not result.is_finite() or not Decimal(minimum)<=result<=Decimal(maximum):
        raise ValueError("숫자 입력 범위를 확인하세요.")
    return result


def valid_quantity(value, asset):
    if not re.fullmatch(r"[0-9]{1,12}(?:\.[0-9]{1,8})?",str(value)):
        raise ValueError("수량은 소수점 이하 8자리까지 입력할 수 있습니다.")
    qty = decimal(value,"0.00000001","10000000000")
    if asset["region"] != "CRYPTO" and qty != qty.to_integral_value():
        raise ValueError("주식 수량은 정수입니다.")
    return qty


def quote_problem(asset, quote, max_age=180):
    if asset["kind"] == "지수":
        return "지수는 가상 체결 대상이 아닙니다."
    if asset["region"] != "CRYPTO":
        return "실시간 주식 호가 데이터가 없어 가상 체결을 보류합니다."
    if asset["state"] not in ACTIVE:
        return "공개 목록에서 거래 상태가 확인될 때까지 보류합니다."
    if not quote or quote.get("quality") != LIVE:
        return "실시간 호가가 없습니다."
    try:
        age = (datetime.now(UTC)-datetime.fromisoformat(quote["time"])).total_seconds()
        captured = (datetime.now(UTC)-datetime.fromisoformat(quote["retrieved"])).total_seconds()
        mark,bid,ask = [decimal(quote[k],"0.000000000001") for k in ("price","bid","ask")]
        if age > max_age or age < -30 or captured > max_age:
            return "오래됐거나 시각이 어긋난 호가입니다."
        if ask<bid or (ask-bid)/bid>Decimal(".05") or not bid*Decimal(".9")<=mark<=ask*Decimal("1.1"):
            return "스프레드 또는 가격에 이상이 있습니다."
    except (KeyError, ValueError, TypeError):
        return "호가 입력이 유효하지 않습니다."
    return None
