from statistics import fmean


def patterns(bars):
    if not bars:
        return {}
    price = bars[-1]
    out = {}
    if len(bars)>=2:
        prev = bars[-2]
        span = price["high"]-price["low"]
        body = abs(price["close"]-price["open"])
        inside = price["high"]<prev["high"] and price["low"]>prev["low"]
        out["price_action"] = {"inside_bar":inside,"higher_high":price["high"]>prev["high"],
                               "lower_low":price["low"]<prev["low"]}
        out["candle"] = {"doji":body<=span*.1 if span else None,
            "bullish_engulfing":prev["close"]<prev["open"] and price["close"]>price["open"] and
            price["open"]<=prev["close"] and price["close"]>=prev["open"],
            "bearish_engulfing":prev["close"]>prev["open"] and price["close"]<price["open"] and
            price["open"]>=prev["close"] and price["close"]<=prev["open"]}
    if len(bars)>=20:
        history = bars[-20:]
        hi,lo = max(b["high"] for b in history),min(b["low"] for b in history)
        out["fibonacci"] = {"window":20,"high":hi,"low":lo,"retracements":
                            {str(v):hi-(hi-lo)*v for v in (.236,.382,.5,.618,.786)}}
        volume = [b["volume"] for b in history]
        if all(v is not None for v in volume):
            base = fmean(volume[:-1])
            out["vsa"] = {"relative_volume":volume[-1]/base if base else None,
                          "relative_range":(price["high"]-price["low"])/max(
                              fmean(b["high"]-b["low"] for b in history[:-1]),1e-12)}
    if len(bars)>=52:
        def mid(n):
            return (max(b["high"] for b in bars[-n:])+min(b["low"] for b in bars[-n:]))/2
        conversion,base = mid(9),mid(26)
        out["ichimoku"] = {"conversion":conversion,"base":base,"span_a_unshifted":(conversion+base)/2,
                           "span_b_unshifted":mid(52),"display_shift":26}
    if len(bars)>=21:
        prior = bars[-21:-1]
        out["breakout"] = {"above_prior_high":price["close"]>max(b["high"] for b in prior),
                           "below_prior_low":price["close"]<min(b["low"] for b in prior)}
    if len(bars)>=40:
        previous,recent = bars[-40:-20],bars[-20:]
        high = max(b["high"] for b in recent)-max(b["high"] for b in previous)
        low = min(b["low"] for b in recent)-min(b["low"] for b in previous)
        out["dow_proxy"] = {"high_change":high,"low_change":low,
                            "state":"고점·저점 상승" if high>0 and low>0 else "고점·저점 하락" if high<0 and low<0 else "불일치"}
    return out
