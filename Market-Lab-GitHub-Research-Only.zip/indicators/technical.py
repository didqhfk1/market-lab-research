import math
import statistics as stats

FIELDS = {
    "sma20":"SMA 20", "ema20":"EMA 20", "rsi14":"RSI 14", "macd":"MACD 12/26",
    "macd_signal":"MACD 신호 9", "macd_hist":"MACD 히스토그램",
    "bb_high":"볼린저 상단 20", "bb_low":"볼린저 하단 20", "atr14":"ATR 14",
    "vwap":"구간 VWAP (봉 근사)", "adx14":"ADX 14", "stoch_k":"Stochastic %K 14",
    "stoch_d":"Stochastic %D 3", "obv":"OBV", "vol_ratio":"최근 거래량 / 이전 20봉 평균",
    "volatility":"20봉 수익률 표준편차 (%)", "support":"20봉 저가", "resistance":"20봉 고가",
    "trend":"SMA 20 대비 종가 (%)",
}


def avg(values, n):
    return stats.fmean(values[-n:]) if len(values)>=n else None


def exponential(values, n, alpha=None):
    if len(values)<n:
        return []
    alpha = 2/(n+1) if alpha is None else alpha
    result = [stats.fmean(values[:n])]
    for value in values[n:]:
        last = result[-1]
        result.append(last + alpha*(value-last))
    return result


def smooth(values, n=14):
    return exponential(values,n,1/n)


def last(values):
    return values[-1] if values else None


def pct(a,b):
    return (a/b-1)*100 if b else None


def technical(bars):
    result = dict.fromkeys(FIELDS)
    if not bars:
        return result
    close = [b["close"] for b in bars]
    volume = [b["volume"] for b in bars]
    high = [b["high"] for b in bars]
    low = [b["low"] for b in bars]
    deltas = [b-a for a,b in zip(close,close[1:])]
    a = smooth([max(0,x) for x in deltas])
    d = smooth([max(0,-x) for x in deltas])
    if a:
        result["rsi14"] = 50 if a[-1] == d[-1] == 0 else (100 if not d[-1] else 100-100/(1+a[-1]/d[-1]))
    result["sma20"] = middle = avg(close,20)
    result["ema20"] = last(exponential(close,20))
    if middle is not None:
        band = 2*stats.pstdev(close[-20:])
        result.update(bb_high=middle+band,bb_low=middle-band,trend=pct(close[-1],middle),
                      support=min(low[-20:]),resistance=max(high[-20:]))
    macd = [x-y for x,y in zip(exponential(close,12)[14:],exponential(close,26))]
    signal = last(exponential(macd,9))
    result.update(macd=last(macd),macd_signal=signal,
                  macd_hist=None if signal is None else macd[-1]-signal)
    tr = [max(h-l,abs(h-prev),abs(l-prev)) for h,l,prev in zip(high[1:],low[1:],close)]
    atr = smooth(tr)
    result["atr14"] = last(atr)
    plus, minus = [], []
    for h,ph,l,pl in zip(high[1:],high,low[1:],low):
        up, down = h-ph, pl-l
        plus.append(up if up>max(down,0) else 0)
        minus.append(down if down>max(up,0) else 0)
    dx = [100*abs(p-m)/(p+m) if a and p+m else 0
          for a,p,m in zip(atr,smooth(plus),smooth(minus))]
    result["adx14"] = last(smooth(dx))
    stochastic = []
    for i in range(13,len(close)):
        hi,lo = max(high[i-13:i+1]),min(low[i-13:i+1])
        stochastic.append((close[i]-lo)/(hi-lo)*100 if hi>lo else 50)
    result.update(stoch_k=last(stochastic),stoch_d=avg(stochastic,3))
    if all(v is not None for v in volume):
        total = sum(volume)
        if total:
            result["vwap"] = sum((h+l+c)/3*v for h,l,c,v in zip(high,low,close,volume))/total
        result["obv"] = sum(v*((d>0)-(d<0)) for d,v in zip(deltas,volume[1:]))
    if len(volume)>=21 and all(v is not None for v in volume[-21:]):
        base = stats.fmean(volume[-21:-1])
        result["vol_ratio"] = volume[-1]/base if base else None
    if len(close)>=21:
        returns = [pct(b,a) for a,b in zip(close[-21:],close[-20:])]
        result["volatility"] = stats.stdev(returns)
    return result


def returns_by_time(bars):
    return {b["time"]:math.log(b["close"]/a["close"]) for a,b in zip(bars,bars[1:])}


def correlation(one,two):
    by_day = lambda bars: {t[:10]:v for t,v in returns_by_time(bars).items()}
    a,b = by_day(one),by_day(two)
    common = sorted(a.keys() & b.keys())[-90:]
    if len(common)<5:
        return {"correlation":None,"count":len(common)}
    try:
        val = stats.correlation([a[k] for k in common],[b[k] for k in common])
    except stats.StatisticsError:
        val = None
    return {"correlation":val,"count":len(common)}
