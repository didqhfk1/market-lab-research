import math
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MARKETS = ("KR", "US", "CRYPTO")


def local_model_name(value):
    return isinstance(value,str) and bool(re.fullmatch(r"[A-Za-z0-9_./:-]{1,80}",value)) and not re.search(
        r"(?i)(^|[/:._-])cloud($|[/:._-])",value)


DEFAULTS = {
    "mode": "analysis", "paused": False, "enabled": True,
    "operator":"idle",
    "markets": list(MARKETS), "watchlist": ["CRYPTO:KRW-BTC", "CRYPTO:BTC-USD"],
    "initial_krw": 10000000, "initial_usd": 10000, "fee_bps": 10,
    "slippage_bps": 5, "spread_bps": 8, "low_spec": True,
    "ai": False, "model": "qwen2.5:1.5b", "ai_per_hour": 12, "ai_crosscheck": True,
    "news_minutes": 30, "community_minutes": 60, "chart_minutes": 15,
    "workers": 2, "retention_days": 365, "cpu_limit": 85, "ram_limit": 85,
    "research_paused": False, "resource_mode": "balanced", "council_rounds": 2, "partial_fills": True,
    "event_ai": False,
    "long_research": True, "short_research": True,
    "automatic_deep_ai": False, "automatic_hypotheses": False,
    "telegram_enabled": False, "telegram_files": False, "telegram_severity":"WARNING",
    "telegram_report_hour":23, "telegram_quiet_start":0, "telegram_quiet_end":0,
    "telegram_categories":["stock","crypto","learning","paper","system","quota","report"],
    "strategy_ids": ["buffett", "graham", "lynch", "dalio", "soros",
                     "marks", "simons", "seykota", "oneil"],
}

def load_env(config=None):
    config = config or ROOT / ".env"
    if config.is_file():
        for line in config.read_text(encoding="utf-8-sig").splitlines():
            key, sep, value = line.partition("=")
            if sep and key.strip() in {"KR_FSC_KEY", "ALPHA_VANTAGE_KEY", "DART_KEY", "SEC_CONTACT",
                                      "TELEGRAM_BOT_TOKEN","TELEGRAM_CHAT_IDS"}:
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

def validate(changes, current):
    if not isinstance(changes, dict) or set(changes) - DEFAULTS.keys():
        raise ValueError("설정 항목을 확인하세요.")
    result = current | changes
    if result["mode"] not in ("analysis", "paper", "backtest", "auto_paper"):
        raise ValueError("실행 모드를 확인하세요.")
    if result["operator"] not in ("idle","running","paused","stopped"):
        raise ValueError("자동 운영 상태를 확인하세요.")
    if result["resource_mode"] not in ("eco","balanced","research","auto"):
        raise ValueError("자원 운영 모드를 확인하세요.")
    if result["telegram_severity"] not in ("CRITICAL","ERROR","WARNING","INFO"):
        raise ValueError("텔레그램 중요도 설정을 확인하세요.")
    if not local_model_name(result["model"]):
        raise ValueError("로컬 Ollama 모델 이름을 입력하세요. 클라우드 모델은 선택할 수 없습니다.")
    for key in ("paused", "enabled", "low_spec", "ai", "research_paused", "partial_fills", "event_ai",
                "long_research", "short_research","telegram_enabled","telegram_files",
                "automatic_deep_ai","automatic_hypotheses","ai_crosscheck"):
        if type(result[key]) is not bool:
            raise ValueError(f"{key} 값은 켜짐 또는 꺼짐이어야 합니다.")
    ranges = {
        "initial_krw": (1, 10**12), "initial_usd": (0.01, 10**9),
        "fee_bps": (0, 200), "slippage_bps": (0, 200), "spread_bps": (0, 200),
        "ai_per_hour": (1, 60), "news_minutes": (5, 1440), "community_minutes": (10, 1440),
        "chart_minutes": (2, 1440), "workers": (1, 4), "retention_days": (30, 3650),
        "cpu_limit": (20, 100), "ram_limit": (20, 100),
        "council_rounds": (0, 2),
        "telegram_report_hour":(0,23),"telegram_quiet_start":(0,23),"telegram_quiet_end":(0,23),
    }
    for key, (minimum, maximum) in ranges.items():
        value = result[key]
        if type(value) not in (float, int) or not math.isfinite(value) or not minimum <= value <= maximum:
            raise ValueError(f"{key} 허용 범위 {minimum}–{maximum}")
        if key.endswith("_minutes") or key.startswith("telegram_") or key in ("workers", "ai_per_hour", "retention_days", "council_rounds"):
            if int(value) != value:
                raise ValueError(f"{key} 값은 정수여야 합니다.")
            result[key] = int(value)
    for key, allowed, maximum in (("markets", MARKETS, 3), ("watchlist", None, 20),
                                  ("strategy_ids", DEFAULTS["strategy_ids"], 9),
                                  ("telegram_categories",DEFAULTS["telegram_categories"],7)):
        values = result[key]
        if not isinstance(values, list) or len(values) > maximum:
            raise ValueError(f"{key} 최대 항목 수는 {maximum}입니다.")
        if any(not isinstance(v, str) or (v not in allowed if allowed else
               not re.fullmatch(r"(KR|US|CRYPTO):[A-Z0-9.^_-]{1,24}", v)) for v in values):
            raise ValueError(f"{key} 항목을 확인하세요.")
        result[key] = list(dict.fromkeys(values))
    return result
