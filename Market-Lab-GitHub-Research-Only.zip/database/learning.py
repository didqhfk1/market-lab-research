import hashlib
import json
import statistics as stats
from datetime import UTC, datetime, timedelta
from uuid import uuid4

from core.models import TEST, now
from database.store import encode
from indicators.technical import returns_by_time

def digest(value):
    return hashlib.sha256(encode(value).encode("utf-8")).hexdigest()


def available_evidence(alias):
    return f"""COALESCE((SELECT json_extract(r.data,'$.state') FROM learning_events r
        WHERE r.kind='learning_review' AND json_extract(r.data,'$.target')={alias}.id
        ORDER BY r.time DESC,r.rowid DESC LIMIT 1),'사용 가능')<>'격리'"""


class Learning:
    def __init__(self, store):
        self.store = store

    def append(self, kind, event_id, asset, payload):
        with self.store.tx() as conn:
            self.append_in(conn,kind,event_id,asset,payload)

    @staticmethod
    def append_in(conn, kind, event_id, asset, payload, at=None):
        from database.audit import append
        at = at or now()
        inserted = conn.execute("INSERT OR IGNORE INTO learning_events VALUES(?,?,?,?,?)",
                                (event_id,kind,asset,at,encode(payload))).rowcount
        if inserted:
            append(conn,"learning",{"id":event_id,"kind":kind,"hash":digest([kind,asset,at,payload]),
                  "snapshot":payload.get("snapshot"),"strategy_version":payload.get("version"),
                  "prompt_version":(payload.get("model") or {}).get("prompt_version")
                  if isinstance(payload.get("model"),dict) else None},at)

    def read(self, event_id):
        result = self.store.query("SELECT * FROM learning_events WHERE id=?",(event_id,))
        return self.decode(result[0]) if result else None

    @staticmethod
    def decode(row):
        return {"id":row["id"],"kind":row["kind"],"asset":row["asset"],"time":row["time"],
                **json.loads(row["data"])}

    def items(self, kind, asset="", limit=80):
        return [self.decode(row) for row in self.store.query(
            "SELECT * FROM learning_events WHERE kind=? AND (?='' OR asset=?) ORDER BY time DESC,id DESC LIMIT ?",
            (kind,asset,asset,limit))]

    def review(self, target, action, reason):
        if (not isinstance(target,str) or len(target)>100 or action not in ("quarantine","restore")
                or not isinstance(reason,str) or not 4<=len(reason.strip())<=250):
            raise ValueError("기록 ID와 사유(4~250자)를 확인하세요.")
        with self.store.tx() as conn:
            row = conn.execute(f"SELECT e.*, {available_evidence('e')} usable FROM learning_events e WHERE e.id=?",
                               (target,)).fetchone()
            if not row or row["kind"] not in ("snapshot","case","outcome","automatic_snapshot","automatic_outcome",
                                              "memory_trial","memory_outcome"):
                raise ValueError("검토할 학습 기록을 찾을 수 없습니다.")
            blocked = action=="quarantine"
            if bool(row["usable"])!=blocked:
                raise ValueError("이 학습 기록은 이미 요청한 상태입니다.")
            data = {"target":target,"target_kind":row["kind"],"state":"격리" if blocked else "사용 가능",
                    "reason":reason.strip()}
            ident = "learning-review-"+uuid4().hex
            self.append_in(conn,"learning_review",ident,row["asset"],data)
        return data | {"id":ident}

    def recent_cases(self, asset="", limit=80):
        return [self.decorate(item) for item in self.items("case",asset,limit)]

    def decorate(self, item, detail=False):
        outcome = self.read("outcome-"+item["id"])
        records = self.store.query("SELECT body FROM orders WHERE json_extract(body,'$.case')=? ORDER BY created",
                                   (item["id"],))
        snapshot = self.read(item["snapshot"])
        result = item | {"outcome":outcome,"orders":[json.loads(row["body"]) for row in records],
                         "summary": {k:snapshot.get(k) for k in
                             ("regime","conflict","close","evidence_count","model","method_pairs")} if snapshot else {}}
        if detail:
            result["input"] = snapshot
        return result

    def capture(self, asset, series, evidence, fundamentals, macro, indicators, scores, reasons,
                conflict, model, market_sample=None):
        from indicators.patterns import patterns
        bars = series["bars"]
        last = bars[-1]
        regime = detect_regime(bars,indicators,evidence,fundamentals,macro,market_sample)
        directions = {name:score for name,score in scores.items() if score is not None}
        pairs = {f"{a} × {b}":("일치" if sa==sb else "충돌" if sa*sb<0 else "중립 혼합")
                 for i,(a,sa) in enumerate(directions.items()) for b,sb in list(directions.items())[i+1:]
                 if a in ("chart","volume","technical","news","community","macro","fundamental")
                 and b in ("chart","volume","technical","news","community","macro","fundamental")}
        fingerprint = {"asset":asset["id"],"source":series["source"],"series_url":series["url"],
                       "quality":series["quality"],"bar_time":last["time"],"bars":bars[-120:],
                       "evidence":[{k:item.get(k) for k in ("id","url","source","published","text","title","scope",
                                                            "certainty","factors","retrieved","fact_status","module","eligible",
                                                            "used_by_module")} for item in evidence],
                       "fundamentals":fundamentals,"macro":macro,"model":model}
        snapshot = fingerprint | {"region":asset["region"],"close":last["close"],"regime":regime,
                "conflict":conflict,"indicators":indicators,"scores":scores,"reasons":reasons,
                "method_pairs":pairs,"evidence_count":len(evidence),"market_sample":market_sample,
                "patterns":patterns(bars)}
        snapshot_id = "snap-"+digest(fingerprint)[:40]
        self.append("snapshot",snapshot_id,asset["id"],snapshot)
        return snapshot_id,regime

    def record_case(self, asset, series, snapshot_id, strategy, score, reason, disposition, config):
        bar = series["bars"][-1]
        direction = ("INVALID" if score is None else "WAIT" if disposition=="보류" else
                     "NEUTRAL" if not score else "LONG" if score==1 else "SHORT")
        ref = digest([asset["id"],series["source"],series["quality"],bar["time"],strategy.id,strategy.version,config["mode"],
                      config["fee_bps"],config["slippage_bps"],config["initial_"+asset["currency"].lower()]])[:40]
        ident = "case-"+ref
        payload = {"snapshot":snapshot_id,"strategy":strategy.id,"version":strategy.version,"score":score,
                   "reason":reason,"state":disposition,"direction":direction,"frame":"1d","basis":bar["time"],"price":bar["close"],
                   "region":asset["region"],"quality":series["quality"],"source":series["source"],
                   "mode":config["mode"],"horizon":3,
                   "assumptions":{k:config[k] for k in ("fee_bps","slippage_bps","spread_bps","initial_krw","initial_usd")}}
        self.append("case",ident,asset["id"],payload)
        return ident

    def evaluate_pending(self, asset_id, series):
        if not series or series["quality"]==TEST:
            return 0
        count = 0
        recent = self.store.query(
            f"SELECT e.* FROM learning_events e WHERE e.kind='case' AND e.asset=? AND {available_evidence('e')} "
            f"AND EXISTS(SELECT 1 FROM learning_events s WHERE s.id=json_extract(e.data,'$.snapshot') "
            f"AND {available_evidence('s')}) AND "
            "NOT EXISTS(SELECT 1 FROM learning_events x WHERE x.id='outcome-'||e.id) ORDER BY e.time DESC LIMIT 200",
            (asset_id,))
        for row in recent:
            case = self.decode(row)
            if case["source"]!=series["source"] or case["quality"]!=series["quality"]:
                continue
            visible = [b for b in series["bars"] if b["time"]>max(case["basis"],row["time"])]
            if len(visible)<case["horizon"]:
                continue
            finish = visible[case["horizon"]-1]
            move = finish["close"]/case["price"]-1
            signal = {"LONG":1,"SHORT":-1,"NEUTRAL":0,"WAIT":0,"INVALID":0}.get(case.get("direction"),case["score"])
            sign = (move>0)-(move<0)
            label = ("의견 없음" if not signal else "성공" if sign==signal else
                     "보합" if sign==0 else "실패")
            reasoning = {"성공":"기록한 방향과 이후 종가 변화 방향이 일치했습니다.",
                         "실패":"기록한 방향과 이후 종가 변화 방향이 달랐습니다.",
                         "보합":"평가 시점 종가가 당시 종가와 같았습니다.",
                         "의견 없음":"중립·판단 보류·입력 부족으로 방향을 평가하지 않았습니다."}
            self.append("outcome","outcome-"+case["id"],asset_id,
                        {"case":case["id"],"basis":case["basis"],"close_time":finish["time"],
                         "close":finish["close"],"return":move,"label":label,"reason":reasoning[label],
                         "uncertainty":"방향 일치 측정이며 원인이나 가상 체결 손익을 뜻하지 않습니다.",
                         "series_url":series["url"]})
            count += 1
        return count

    def overview(self):
        query = f"""SELECT json_extract(c.data,'$.strategy') strategy,
         json_extract(c.data,'$.version') version,json_extract(c.data,'$.region') region,
         json_extract(c.data,'$.quality') quality,json_extract(c.data,'$.direction') direction,
         json_extract(s.data,'$.regime.trend') regime,json_extract(s.data,'$.conflict') conflict,
         COUNT(*) samples,SUM(o.id IS NOT NULL) evaluated,
         SUM(json_extract(o.data,'$.label')='성공') wins,
         SUM(json_extract(o.data,'$.label')='실패') losses,
         SUM(json_extract(c.data,'$.state') IN ('보류','근거 부족')) held,
         AVG(CASE json_extract(c.data,'$.direction') WHEN 'LONG' THEN json_extract(o.data,'$.return')
         WHEN 'SHORT' THEN -json_extract(o.data,'$.return') ELSE NULL END) mean_signed_move
         FROM learning_events c JOIN learning_events s ON s.id=json_extract(c.data,'$.snapshot')
         LEFT JOIN learning_events o ON o.id='outcome-'||c.id AND {available_evidence('o')}
         WHERE c.kind='case' AND {available_evidence('c')} AND {available_evidence('s')}
         GROUP BY strategy,version,region,quality,regime,conflict,direction ORDER BY strategy,version,region,direction"""
        entries = self.store.query(query)
        counts = self.store.query("SELECT kind,COUNT(*) total FROM learning_events GROUP BY kind")
        return {"groups":entries,"counts":counts,
                "notice":"전략·버전·시장·데이터 유형별 관측 간 비교입니다. 방향 변화와 체결 손익은 별개입니다."}

    def similar(self, asset, regime, limit=8):
        sample = self.store.query(
            f"""SELECT c.* FROM learning_events c JOIN learning_events s ON s.id=json_extract(c.data,'$.snapshot')
             JOIN learning_events o ON o.id='outcome-'||c.id WHERE c.kind='case'
             AND {available_evidence('c')} AND {available_evidence('s')} AND {available_evidence('o')}
             AND json_extract(c.data,'$.region')=? AND json_extract(c.data,'$.quality')!='테스트'
             AND json_extract(s.data,'$.source')!='CSV'
             AND json_extract(s.data,'$.regime.trend')=? ORDER BY (c.asset=?) DESC,c.time DESC,c.id DESC LIMIT ?""",
            (asset["region"],regime,asset["id"],limit))
        return [self.decorate(self.decode(r)) for r in sample]


def detect_regime(bars, indicators, evidence, company, macro, market_sample):
    trend = market_sample["trend"] if market_sample else indicators["trend"]
    vol = market_sample["volatility"] if market_sample else indicators["volatility"]
    volume = indicators["vol_ratio"]
    end = datetime.fromisoformat(bars[-1]["time"])
    def recent(date_value):
        if not date_value:
            return False
        parsed = datetime.fromisoformat(date_value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)+timedelta(hours=23,minutes=59)
        return timedelta(0)<=end-parsed<=timedelta(days=3)
    sentiment = [x for x in evidence if x["source"]=="Hacker News" and x.get("published")]
    newer = [e["factors"]["score"] for e in sentiment if recent(e["published"])]
    older = [e["factors"]["score"] for e in sentiment if not recent(e["published"])]
    change = stats.fmean(newer)-stats.fmean(older) if len(newer)>=3 and len(older)>=3 else None
    return {"trend":"자료 부족" if trend is None else "상승" if trend>2 else "하락" if trend<-2 else "횡보",
            "scope":"벤치마크" if market_sample else "종목 기준",
            "volatility":"자료 부족" if vol is None else "고변동" if vol>3 else "저변동" if vol<1 else "보통",
            "volume_spike": None if volume is None else volume>=1.5,
            "near_news":any(e["source"]!="Hacker News" and recent(e["published"]) for e in evidence),
            "near_macro":any(recent(m.get("release")) for m in macro) if any(m.get("release") for m in macro) else None,
            "near_earnings":any(recent(f.get("publication")) and any(
                tag in f["title"] for tag in ("10-Q","10-K","실적","사업보고서","분기보고서"))
                for f in company.get("filings",[])) if company else None,
            "sentiment_change":change,"sentiment_spike":None if change is None else abs(change)>=.5}


def community_stats(items, bars):
    daily = {}
    for item in items:
        if item.get("published"):
            day = item["published"][:10]
            daily.setdefault(day,[]).append(item["factors"]["score"])
    result = [{"date":day,"mentions":len(samples),"sentiment":stats.fmean(samples)}
              for day,samples in sorted(daily.items())]
    mentions = [r["mentions"] for r in result]
    price = {time[:10]:ret for time,ret in returns_by_time(bars).items()}
    matching = [(price[r["date"]],r["sentiment"]) for r in result if r["date"] in price]
    correlation = None
    if len(matching)>=5:
        try:
            correlation = stats.correlation(*zip(*matching))
        except stats.StatisticsError:
            pass
    return {"daily":result,"spike":bool(len(mentions)>=4 and mentions[-1]>=max(3,stats.fmean(mentions[:-1])*2)),
            "duplicates":sum(bool(i.get("duplicate")) for i in items),
            "promotional":sum(bool(i["factors"]["promotional"]) for i in items),
            "rumors":sum(bool(i["factors"]["rumor"]) for i in items),
            "corr":correlation,"corr_sample":len(matching)}
