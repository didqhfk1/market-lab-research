from contextlib import closing, contextmanager
from dataclasses import asdict
from datetime import UTC, datetime, timedelta
from pathlib import Path
import json
import sqlite3

from config.settings import DEFAULTS, local_model_name, validate
from core.models import now

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS assets (id TEXT PRIMARY KEY, region TEXT NOT NULL, body TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS assets_region ON assets(region,id);
CREATE TABLE IF NOT EXISTS series (
 asset TEXT, frame TEXT, source TEXT, updated TEXT NOT NULL, body TEXT NOT NULL,
 PRIMARY KEY(asset,frame,source)
);
CREATE INDEX IF NOT EXISTS series_updated ON series(updated);
CREATE TABLE IF NOT EXISTS records (
 kind TEXT, id TEXT, updated TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(kind,id)
);
CREATE INDEX IF NOT EXISTS records_updated ON records(kind,updated DESC);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY, time TEXT NOT NULL, level TEXT NOT NULL, area TEXT NOT NULL, message TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_time ON events(time);
CREATE TABLE IF NOT EXISTS wallets (
 id TEXT, currency TEXT, initial TEXT NOT NULL, cash TEXT NOT NULL, realized TEXT NOT NULL,
 PRIMARY KEY(id,currency)
);
CREATE TABLE IF NOT EXISTS positions (
 wallet TEXT, asset TEXT, qty TEXT NOT NULL, avg TEXT NOT NULL, PRIMARY KEY(wallet,asset)
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, wallet TEXT NOT NULL, asset TEXT NOT NULL, state TEXT NOT NULL,
 created TEXT NOT NULL, body TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS orders_state ON orders(state,created);
CREATE INDEX IF NOT EXISTS orders_case ON orders(json_extract(body,'$.case'));
CREATE TABLE IF NOT EXISTS budgets (bucket TEXT PRIMARY KEY, calls INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS learning_events (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL, asset TEXT NOT NULL, time TEXT NOT NULL, data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS learning_asset ON learning_events(kind,asset,time DESC);
CREATE INDEX IF NOT EXISTS learning_time ON learning_events(kind,time DESC);
CREATE TRIGGER IF NOT EXISTS keep_research_update BEFORE UPDATE ON learning_events
BEGIN SELECT RAISE(ABORT,'Learning records are append-only'); END;
CREATE TRIGGER IF NOT EXISTS keep_research_delete BEFORE DELETE ON learning_events
BEGIN SELECT RAISE(ABORT,'Learning records are append-only'); END;
CREATE TABLE IF NOT EXISTS audit_ledger (
 seq INTEGER PRIMARY KEY, time TEXT NOT NULL, action TEXT NOT NULL,
 previous TEXT NOT NULL, checksum TEXT NOT NULL UNIQUE, body TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ledger_evidence ON audit_ledger(action,json_extract(body,'$.id'));
CREATE TRIGGER IF NOT EXISTS keep_audit_update BEFORE UPDATE ON audit_ledger
BEGIN SELECT RAISE(ABORT,'Audit records are append-only'); END;
CREATE TRIGGER IF NOT EXISTS keep_audit_delete BEFORE DELETE ON audit_ledger
BEGIN SELECT RAISE(ABORT,'Audit records are append-only'); END;
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY, key TEXT NOT NULL, task TEXT NOT NULL, priority INTEGER NOT NULL,
 status TEXT NOT NULL, created TEXT NOT NULL, updated TEXT NOT NULL, body TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS jobs_queue ON jobs(status,priority,created);
CREATE UNIQUE INDEX IF NOT EXISTS jobs_active ON jobs(key) WHERE status IN ('대기','실행');
CREATE TABLE IF NOT EXISTS notifications (
 id TEXT PRIMARY KEY, event_id TEXT NOT NULL, category TEXT NOT NULL, severity TEXT NOT NULL,
 priority INTEGER NOT NULL, created TEXT NOT NULL, sent TEXT, status TEXT NOT NULL,
 attempt INTEGER NOT NULL, next_at TEXT NOT NULL, message_id INTEGER, error TEXT, body TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS notifications_due ON notifications(status,priority,next_at,created);
CREATE TABLE IF NOT EXISTS auto_accounts (
 region TEXT, direction TEXT, currency TEXT, initial TEXT NOT NULL, cash TEXT NOT NULL, realized TEXT NOT NULL,
 PRIMARY KEY(region,direction,currency)
);
CREATE TABLE IF NOT EXISTS auto_cycles (
 id TEXT PRIMARY KEY, asset TEXT NOT NULL, region TEXT NOT NULL, state TEXT NOT NULL,
 updated TEXT NOT NULL, body TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS auto_active_asset ON auto_cycles(asset) WHERE state IN ('진입 대기','가상 보유');
CREATE INDEX IF NOT EXISTS auto_cycles_state ON auto_cycles(region,state,updated);
CREATE TRIGGER IF NOT EXISTS keep_auto_cycle_closed BEFORE UPDATE ON auto_cycles
 WHEN OLD.state IN ('가상 청산','취소')
 BEGIN SELECT RAISE(ABORT,'Completed automatic research is immutable'); END;
CREATE TRIGGER IF NOT EXISTS keep_auto_cycle_delete BEFORE DELETE ON auto_cycles
 BEGIN SELECT RAISE(ABORT,'Automatic research must be retained'); END;
CREATE TRIGGER IF NOT EXISTS keep_auto_cycle_frozen BEFORE UPDATE ON auto_cycles
 WHEN OLD.state='세션 종료 · 평가 동결'
 BEGIN SELECT RAISE(ABORT,'Archived automatic research is immutable'); END;
CREATE TABLE IF NOT EXISTS auto_sessions (
 id TEXT PRIMARY KEY, created TEXT NOT NULL, started TEXT, ended TEXT,
 state TEXT NOT NULL CHECK(state IN ('waiting','running','paused','ended','stopped')),
 currency_krw TEXT NOT NULL, currency_usd TEXT NOT NULL, body TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS auto_one_session ON auto_sessions((1)) WHERE ended IS NULL;
CREATE TABLE IF NOT EXISTS auto_session_accounts (
 session TEXT REFERENCES auto_sessions(id), region TEXT, direction TEXT, currency TEXT,
 initial TEXT NOT NULL, added TEXT NOT NULL, cash TEXT NOT NULL, realized TEXT NOT NULL,
 PRIMARY KEY(session,region,direction,currency)
);
CREATE TABLE IF NOT EXISTS auto_session_reports (
 session TEXT REFERENCES auto_sessions(id), name TEXT NOT NULL, PRIMARY KEY(session,name)
);
CREATE TRIGGER IF NOT EXISTS keep_auto_sessions_delete BEFORE DELETE ON auto_sessions
 BEGIN SELECT RAISE(ABORT,'Automatic sessions must be retained'); END;
CREATE TRIGGER IF NOT EXISTS keep_auto_session_closed BEFORE UPDATE ON auto_sessions
 WHEN OLD.ended IS NOT NULL BEGIN SELECT RAISE(ABORT,'Completed automatic sessions must be retained'); END;
CREATE INDEX IF NOT EXISTS learning_review_target ON learning_events(json_extract(data,'$.target'),time DESC)
 WHERE kind='learning_review';
CREATE INDEX IF NOT EXISTS learning_trade_timeline ON learning_events(json_extract(data,'$.cycle'),time)
 WHERE kind='trade_lifecycle';
CREATE INDEX IF NOT EXISTS learning_interim_cycle ON learning_events(json_extract(data,'$.cycle'),time)
 WHERE kind='automatic_interim_evaluation';
"""
VERSION = 6


def encode(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self.connect()) as conn:
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            if version>VERSION:
                raise RuntimeError("데이터베이스 버전이 프로그램보다 새롭습니다.")
            if conn.execute("PRAGMA quick_check(1)").fetchone()[0]!="ok":
                raise RuntimeError("기존 데이터베이스가 무결성 검사를 통과하지 못했습니다. 백업을 확인하세요.")
            if version and version<VERSION:
                target = self.path.with_suffix(f".v{version}.before-migration.sqlite")
                if not target.exists():
                    pending=target.with_suffix(".verified-copy.tmp")
                    self.backup_to(pending)
                    pending.replace(target)
            conn.execute("PRAGMA journal_mode=WAL")
            if version<VERSION:
                try:
                    conn.executescript("BEGIN IMMEDIATE;\n"+SCHEMA)
                    self.ledger_migration(conn,version)
                    if conn.execute("PRAGMA quick_check(1)").fetchone()[0]!="ok":
                        raise RuntimeError("스키마 변경 이후 무결성 점검에 실패했습니다.")
                    conn.commit()
                except BaseException:
                    conn.rollback()
                    raise

    @staticmethod
    def ledger_migration(conn,previous_version):
        from database.audit import append
        from database.learning import digest
        if "session" not in {row["name"] for row in conn.execute("PRAGMA table_info(auto_cycles)")}:
            conn.execute("ALTER TABLE auto_cycles ADD COLUMN session TEXT NOT NULL DEFAULT 'legacy'")
        conn.execute("CREATE INDEX IF NOT EXISTS auto_cycles_session ON auto_cycles(session,state,region)")
        if previous_version<5:
            for row in conn.execute("""SELECT * FROM learning_events e WHERE NOT EXISTS(
              SELECT 1 FROM audit_ledger a WHERE a.action='learning' AND json_extract(a.body,'$.id')=e.id)
              ORDER BY time,id""").fetchall():
                append(conn,"learning",{"id":row["id"],"kind":row["kind"],
                       "hash":digest([row["kind"],row["asset"],row["time"],json.loads(row["data"])])},row["time"])
        from core.runtime import VERSION as APP_VERSION
        append(conn,"database_migration",{"previous_schema":previous_version,"schema":VERSION,
                                          "version":APP_VERSION,"state":"committed"})
        conn.execute(f"PRAGMA user_version={VERSION}")

    def connect(self):
        conn = sqlite3.connect(self.path, timeout=8, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA trusted_schema=OFF")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA synchronous=FULL")
        return conn

    @contextmanager
    def tx(self):
        with closing(self.connect()) as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
                conn.commit()
            except BaseException:
                conn.rollback()
                raise

    def query(self, sql, args=()):
        with closing(self.connect()) as conn:
            return [dict(row) for row in conn.execute(sql, args)]

    def write(self, sql, args=()):
        with self.tx() as conn:
            conn.execute(sql, args)

    def settings(self, conn=None):
        if conn is not None:
            row = conn.execute("SELECT body FROM settings WHERE id=1").fetchone()
        else:
            rows = self.query("SELECT body FROM settings WHERE id=1")
            row = rows[0] if rows else None
        settings=DEFAULTS | (json.loads(row["body"]) if row else {})
        if not local_model_name(settings["model"]):
            settings.update(model=DEFAULTS["model"],ai=False)
        return settings

    def configure(self, changes):
        with self.tx() as conn:
            return self.configure_in(conn,changes)

    def configure_in(self, conn, changes):
        from database.audit import append
        from core.runtime import VERSION as APP_VERSION
        old=self.settings(conn)
        result=validate(changes,old)
        changed={key for key in result if result[key]!=old[key]}
        session=conn.execute("SELECT id FROM auto_sessions WHERE ended IS NULL").fetchone()
        conn.execute("INSERT OR REPLACE INTO settings VALUES(1,?)",(encode(result),))
        if changed:
            keys=sorted(changed)
            area=lambda key: ("AI" if key.startswith("ai") or key=="model" else
                              "텔레그램" if key.startswith("telegram") else
                              "모의투자" if key.startswith(("initial_","long_","short_")) or key in
                                  ("mode","operator","paused","enabled","fee_bps","spread_bps","slippage_bps") else "운영·연구")
            append(conn,"settings",{"changes":{key:result[key] for key in keys},"before":{key:old[key] for key in keys},
                   "sections":sorted({area(key) for key in keys}),"session":session["id"] if session else None,
                   "version":APP_VERSION,"schema":VERSION})
        return result

    def assets(self, items, *, seed=False):
        policy = "IGNORE" if seed else "REPLACE"
        with self.tx() as conn:
            conn.executemany(f"INSERT OR {policy} INTO assets VALUES(?,?,?)",
                             [(a.id, a.region, encode(asdict(a))) for a in items])

    def asset(self, asset_id):
        rows = self.query("SELECT body FROM assets WHERE id=?", (asset_id,))
        if not rows:
            raise ValueError("종목을 찾을 수 없습니다.")
        return json.loads(rows[0]["body"])

    def search(self, region="", term="", limit=80):
        pattern = "%" + term.replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%"
        rows = self.query(
            "SELECT body FROM assets WHERE (?='' OR region=?) AND (id LIKE ? ESCAPE '!' OR "
            "json_extract(body,'$.name') LIKE ? ESCAPE '!') ORDER BY id LIMIT ?",
            (region, region, pattern, pattern, limit),
        )
        return [json.loads(row["body"]) for row in rows]

    def search_exact(self, asset_id):
        try:
            return self.asset(asset_id)
        except ValueError:
            return None

    def put_series(self, asset_id, frame, value):
        storage_source = "CSV:TEST" if value["quality"]=="테스트" else value["source"]
        with self.tx() as conn:
            previous = conn.execute("SELECT body FROM series WHERE asset=? AND frame=? AND source=?",
                                    (asset_id,frame,storage_source)).fetchone()
            if previous and value["source"]!="CSV":
                past = json.loads(previous["body"])
                if past["quality"]==value["quality"] and past["adjustment"]==value["adjustment"]:
                    merged = {bar["time"]:bar for bar in past["bars"]}
                    merged.update({bar["time"]:bar for bar in value["bars"]})
                    value = value | {"bars":[merged[t] for t in sorted(merged)[-2500:]]}
            conn.execute("INSERT OR REPLACE INTO series VALUES(?,?,?,?,?)",
                         (asset_id,frame,storage_source,now(),encode(value)))

    def series(self, asset_id, frame, test=False):
        rows = self.query(
            "SELECT body FROM series WHERE asset=? AND frame=? AND (json_extract(body,'$.quality')='테스트')=? "
            "ORDER BY (source LIKE 'CSV%') ASC,updated DESC,source LIMIT 1",
            (asset_id, frame, int(test)),
        )
        return json.loads(rows[0]["body"]) if rows else None

    def put(self, kind, item_id, value):
        self.write("INSERT OR REPLACE INTO records VALUES(?,?,?,?)", (kind, item_id, now(), encode(value)))

    def get(self, kind, item_id):
        rows = self.query("SELECT body FROM records WHERE kind=? AND id=?", (kind, item_id))
        return json.loads(rows[0]["body"]) if rows else None

    def list(self, kind, limit=100):
        return [json.loads(row["body"]) for row in self.query(
            "SELECT body FROM records WHERE kind=? ORDER BY updated DESC,id DESC LIMIT ?", (kind, limit))]

    def event(self, level, area, message):
        self.write("INSERT INTO events(time,level,area,message) VALUES(?,?,?,?)",
                   (now(), level, area, message[:500]))

    def charge(self, bucket, limit):
        with self.tx() as conn:
            cursor = conn.execute(
                "INSERT INTO budgets VALUES(?,1) ON CONFLICT(bucket) DO UPDATE SET calls=calls+1 WHERE calls<?",
                (bucket, limit),
            )
            return cursor.rowcount == 1

    def cleanup(self, retention):
        cutoff = (datetime.now(UTC) - timedelta(days=retention)).isoformat(timespec="seconds")
        with self.tx() as conn:
            conn.execute("DELETE FROM records WHERE updated<? AND kind IN "
                         "('quote','auto_candidate','auto_ticker')", (cutoff,))

    def backup_to(self, target):
        with closing(self.connect()) as source, closing(sqlite3.connect(target)) as backup:
            source.backup(backup)
            if backup.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("백업 무결성을 확인할 수 없습니다.")

    def restore_from(self, target):
        if not Path(target).is_file() or Path(target).resolve() == self.path.resolve():
            raise ValueError("별도의 백업 파일을 선택하세요.")
        with closing(sqlite3.connect(Path(target).resolve().as_uri() + "?mode=ro", uri=True)) as source:
            source.execute("PRAGMA trusted_schema=OFF")
            with closing(self.connect()) as dest:
                schema = "SELECT type,name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name"
                if (source.execute("PRAGMA user_version").fetchone()[0] != VERSION
                        or source.execute("PRAGMA integrity_check").fetchone()[0] != "ok"
                        or source.execute(schema).fetchall() != [tuple(row) for row in dest.execute(schema)]):
                    raise ValueError("이 버전의 정상 백업 파일을 선택하세요.")
                source.backup(dest)
