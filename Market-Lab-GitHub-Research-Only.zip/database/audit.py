import json

from core.models import now
from database.learning import digest
from database.store import encode


def append(conn, action, record, at=None):
    recent = conn.execute("SELECT checksum FROM audit_ledger ORDER BY seq DESC LIMIT 1").fetchone()
    prev = recent["checksum"] if recent else "0"*64
    timestamp = at or now()
    value = digest([prev, timestamp, action, record])
    conn.execute("INSERT INTO audit_ledger(time,action,previous,checksum,body) VALUES(?,?,?,?,?)",
                 (timestamp,action,prev,value,encode(record)))
    return value


def verify(store):
    # One read transaction gives a consistent audit and evidence view during writes.
    from contextlib import closing
    expected = "0"*64
    checked = 0
    with closing(store.connect()) as conn:
        conn.execute("BEGIN")
        health = conn.execute("PRAGMA quick_check").fetchone()[0]
        if health!="ok":
            return {"ok":False,"records":checked,"first_error":"SQLite", "head":expected}
        for row in conn.execute("SELECT * FROM audit_ledger ORDER BY seq"):
            body = json.loads(row["body"])
            computed = digest([expected,row["time"],row["action"],body])
            if row["previous"]!=expected or row["checksum"]!=computed:
                return {"ok":False,"records":checked,"first_error":row["seq"],"head":expected}
            if row["action"]=="learning":
                event = conn.execute("SELECT * FROM learning_events WHERE id=?",(body["id"],)).fetchone()
                if not event or digest([event["kind"],event["asset"],event["time"],json.loads(event["data"])])!=body["hash"]:
                    return {"ok":False,"records":checked,"first_error":row["seq"],"head":expected}
            checked += 1
            expected = row["checksum"]
        uncovered = conn.execute("""SELECT COUNT(*) FROM learning_events e
          WHERE NOT EXISTS(SELECT 1 FROM audit_ledger a WHERE a.action='learning'
          AND json_extract(a.body,'$.id')=e.id)""").fetchone()[0]
        for cycle in conn.execute("""SELECT id,body FROM auto_cycles WHERE state IN
            ('가상 청산','취소','세션 종료 · 평가 동결')"""):
            ledger = conn.execute("""SELECT body FROM audit_ledger WHERE action='auto_simulation'
                AND json_extract(body,'$.id')=? ORDER BY seq DESC LIMIT 1""",(cycle["id"],)).fetchone()
            if not ledger or json.loads(ledger["body"])["hash"]!=digest(json.loads(cycle["body"])):
                return {"ok":False,"records":checked,"first_error":cycle["id"],"head":expected}
    return {"ok":not uncovered,"records":checked,"first_error":"미연결 학습 기록" if uncovered else None,
            "head":expected,"note":"로컬 변조 탐지용입니다. 관리자 권한의 재작성에는 외부 증명이 필요합니다."}
