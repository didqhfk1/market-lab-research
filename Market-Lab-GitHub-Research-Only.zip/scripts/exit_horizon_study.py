"""Reproduce a fixed, read-only crypto hold-period study without opening a database."""

import argparse
import csv
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path

from config.settings import DEFAULTS
from core.models import Bar
from indicators.technical import technical
from providers.http import ProviderError, fetch_json
from providers.markets import COINBASE, UPBIT
from simulation.automatic import _liquidation_value, position_limits, select_signal
from simulation.exit_rules import FIXED_EXIT_BARS, decide_exit
from strategies.research import evaluate


STEP = timedelta(minutes=5)
WINDOW = timedelta(hours=12)
DATES = ("2026-11-10", "2026-11-12", "2026-11-16", "2026-11-18")
MARKETS = (("Upbit", "KRW-BTC"), ("Upbit", "KRW-ETH"),
           ("Coinbase", "BTC-USD"), ("Coinbase", "ETH-USD"))
SIGNALS = DEFAULTS | {"long_research": True, "short_research": True}
MAX_LOOKBACK = 200
COSTS = {key: DEFAULTS[key] for key in ("fee_bps", "slippage_bps", "spread_bps")}
SOURCES = {"Upbit": "https://docs.upbit.com/kr/reference/list-candles-minutes",
           "Coinbase": "https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles"}


def as_time(value):
    return datetime.fromisoformat(value).astimezone(UTC)


def read_bars(provider, symbol, start, end):
    if provider == "Upbit":
        payload = fetch_json(UPBIT + "/candles/minutes/5",
                             {"market": symbol, "count": 200, "to": end.isoformat()}, timeout=8)
        raw = [(as_time(r["candle_date_time_utc"] + "+00:00"), r["opening_price"], r["high_price"],
                r["low_price"], r["trade_price"], r["candle_acc_trade_volume"]) for r in payload]
    else:
        payload = fetch_json(f"{COINBASE}/{symbol}/candles",
            {"start": start.isoformat(), "end": end.isoformat(), "granularity": 300}, timeout=8)
        raw = [(datetime.fromtimestamp(t, UTC), op, hi, lo, cl, vol) for t, lo, hi, op, cl, vol in payload]
    seen = {}
    for opened, op, hi, lo, cl, vol in raw:
        if start <= opened < end:
            bar = Bar.make((opened+STEP).isoformat(), op, hi, lo, cl, vol)
            seen[bar.time] = {"time": bar.time, "open": bar.open, "high": bar.high, "low": bar.low,
                              "close": bar.close, "volume": bar.volume}
    return [seen[key] for key in sorted(seen)]


def collect():
    results = []
    for provider, symbol in MARKETS:
        for day in DATES:
            for hour in (0, 12):
                start = as_time(f"{day}T{hour:02}:00:00+00:00")
                end = start + WINDOW
                row = {"provider": provider, "symbol": symbol, "start": start.isoformat(), "end": end.isoformat(),
                       "retrieved": datetime.now(UTC).isoformat(timespec="seconds"), "source": SOURCES[provider]}
                try:
                    row["bars"] = read_bars(provider, symbol, start, end)
                except (ProviderError, ValueError, KeyError, TypeError) as exc:
                    row["bars"] = []
                    row["error"] = str(exc)
                results.append(row)
                print(provider, symbol, day, hour, len(row["bars"]), row.get("error", ""), flush=True)
    return results


def trial(bars, entry_idx, direction, signals, horizon):
    fee = Decimal(COSTS["fee_bps"])/10000
    friction = (Decimal(COSTS["slippage_bps"])+Decimal(COSTS["spread_bps"])/2)/10000
    sign = 1 if direction == "LONG" else -1
    entry = Decimal(str(bars[entry_idx]["close"]))*(1+sign*friction)
    trade = {"direction": direction, "entry": str(entry), "notional": "1", "qty": str(1/entry)} | COSTS
    last = entry_idx
    reason = "censored.window_end"
    for idx in range(entry_idx+1, len(bars)):
        if as_time(bars[idx]["time"])-as_time(bars[last]["time"]) != STEP:
            reason = "censored.missing_bar"
            break
        last = idx
        close = Decimal(str(bars[idx]["close"]))
        _, _, value = _liquidation_value(trade,close)
        rule, _ = decide_exit(direction,signals[idx],value,sign*(close/entry-1),idx-entry_idx,horizon)
        if rule != "hold.no_exit" and bars[idx]["volume"]:
            reason = rule
            break
    _, _, value = _liquidation_value(trade, Decimal(str(bars[last]["close"])))
    realized = reason.startswith("exit.")
    net = round((value-1-fee)*100, 6)
    return {"rule": reason, "last_at": bars[last]["time"], "bars": last-entry_idx,
            "realized_pct": net if realized else None, "mark_pct": None if realized else net}


def compare(dataset):
    provenance, comparisons = [], []
    for row in dataset:
        bars = row["bars"]
        start, end = as_time(row["start"]), as_time(row["end"])
        times = [as_time(bar["time"]) for bar in bars]
        if times != sorted(set(times)) or any(not (start < at <= end and (at-start)%STEP == timedelta(0)) for at in times):
            raise ValueError("연구 입력에 정렬·중복·시각 오류가 있습니다.")
        meta = {k: v for k, v in row.items() if k != "bars"}
        provenance.append(meta | {"observed_bars": len(bars), "missing_bars": int((end-start)/STEP)-len(bars),
                                  "sha256": sha256(json.dumps(bars,sort_keys=True).encode()).hexdigest()})
        signals = [None]*len(bars)
        first = 0
        for idx in range(len(bars)):
            if idx and times[idx]-times[idx-1] != STEP:
                first = idx
            if idx-first >= 49:
                history = bars[max(first,idx+1-MAX_LOOKBACK):idx+1]
                signals[idx] = select_signal(evaluate(history,technical(history))[0],SIGNALS)[0]
        for idx in range(49, len(bars)-1):
            if signals[idx] and times[idx+1]-times[idx] == STEP and times[idx+1] <= end-timedelta(hours=3):
                if bars[idx+1]["volume"]:
                    fixed = trial(bars,idx+1,signals[idx],signals,FIXED_EXIT_BARS["CRYPTO"])
                    unlimited = trial(bars,idx+1,signals[idx],signals,None)
                    comparisons.append({k: row[k] for k in ("provider","symbol","start","end")} |
                        {"direction": signals[idx], "signal_at": bars[idx]["time"], "entry_at": bars[idx+1]["time"]} |
                        {"fixed_"+k: v for k,v in fixed.items()} | {"unlimited_"+k: v for k,v in unlimited.items()})
                    break
    return provenance, comparisons


def save_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w",encoding="utf-8-sig",newline="") as file:
        out = csv.DictWriter(file,fields)
        out.writeheader()
        out.writerows(rows)


def compare_sizing(dataset, comparisons):
    bars={(row["provider"],row["symbol"],bar["time"]):bar for row in dataset for bar in row["bars"]}
    # Default all-market sessions have four KRW and four USD directional pools.
    fee=Decimal(COSTS["fee_bps"])/10000
    results=[]
    for pair in comparisons:
        entry=bars[(pair["provider"],pair["symbol"],pair["entry_at"])]
        currency="KRW" if pair["provider"]=="Upbit" else "USD"
        initial=Decimal(DEFAULTS["initial_"+currency.lower()])/4
        minimum=Decimal(100 if currency=="KRW" else 1)
        for fraction in map(Decimal,(".01",".025",".05")):
            limits=position_limits(initial,initial,fee,Decimal(str(entry["close"])),
                                   Decimal(str(entry["volume"])),capital_fraction=fraction)
            cause=min(limits,key=limits.get)
            notional=limits[cause]
            results.append({k:pair[k] for k in ("provider","symbol","direction","entry_at")} |
                {"currency":currency,"account_initial":initial,"capital_fraction":fraction,"limit":cause,
                 "cash_limit":limits["수수료 포함 가용 현금"],"liquidity_limit":limits["완료 봉 거래대금의 0.1% 추정"],
                 "max_notional":round(notional,8),"filled_in_trial":notional>=minimum,
                 "virtual_pnl":round(notional*pair["fixed_realized_pct"]/100,8)
                   if notional>=minimum and pair["fixed_realized_pct"] is not None else None})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input",type=Path,help="로컬 과거 자료 스냅샷")
    parser.add_argument("output",type=Path,help="감사 CSV 폴더")
    parser.add_argument("--fetch",action="store_true",help="고정 기간의 공개 캔들을 새 스냅샷에 기록")
    args = parser.parse_args()
    if args.fetch:
        with args.input.open("x",encoding="utf-8") as file:
            json.dump(collect(),file,ensure_ascii=False)
    dataset = json.loads(args.input.read_text(encoding="utf-8"))
    provenance, comparisons = compare(dataset)
    save_csv(args.output/"EXIT_HORIZON_PROVENANCE.csv",provenance)
    save_csv(args.output/"EXIT_HORIZON_COMPARISON.csv",comparisons)
    save_csv(args.output/"SIZING_COMPARISON.csv",compare_sizing(dataset,comparisons))
    print("windows",len(provenance),"pairs",len(comparisons))
    if not comparisons:
        raise SystemExit("독립 비교를 완료할 수 있는 공개 봉이 없습니다.")


if __name__ == "__main__":
    main()
