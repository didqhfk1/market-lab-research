"""Run the bounded historical study outside the operational Market Lab database."""

import argparse
import json
import os
from pathlib import Path
from time import perf_counter, process_time

from core.remote_research import HEX40, PROTOCOL, SCHEMA, checked_report, fingerprint
from scripts.exit_horizon_study import collect, compare, compare_sizing


def calculate(dataset, commit, attempt):
    elapsed, cpu = perf_counter(), process_time()
    source, pairs = compare(dataset)
    sizes = compare_sizing(dataset,pairs)
    if len(source)!=32 or not pairs:
        raise ValueError("고정 연구 기간의 비교 표본을 확보하지 못했습니다.")
    source_keys=("provider","symbol","start","end","sha256")
    payload={"schema":SCHEMA,"protocol":PROTOCOL,"commit":commit,"attempt":attempt,
             "input_sha256":fingerprint([{k:row[k] for k in source_keys} for row in source]),
             "result_sha256":fingerprint([pairs,sizes]),
             "metrics":{"windows":len(source),"bars":sum(row["observed_bars"] for row in source),
                        "missing_bars":sum(row["missing_bars"] for row in source),
                        "pairs":len(pairs),"fixed_exits":sum(row["fixed_realized_pct"] is not None for row in pairs),
                        "unlimited_exits":sum(row["unlimited_realized_pct"] is not None for row in pairs),
                        "compute_ms":round((perf_counter()-elapsed)*1000),"cpu_ms":round((process_time()-cpu)*1000)}}
    return payload | {"checksum":fingerprint(payload)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,help="Optional local snapshot for a same-input timing comparison.")
    parser.add_argument("--out",type=Path)
    args=parser.parse_args()
    commit=os.environ.get("GITHUB_SHA","0"*40)
    attempt=int(os.environ.get("GITHUB_RUN_ATTEMPT","1"))
    if not HEX40.fullmatch(commit) or attempt<1:
        parser.error("Invalid run metadata")
    dataset=json.loads(args.input.read_text(encoding="utf-8")) if args.input else collect()
    report=calculate(dataset,commit,attempt)
    checked_report(report)
    text=json.dumps(report,ensure_ascii=False,indent=2)
    if args.out:
        args.out.write_text(text+"\n",encoding="utf-8")
    print(text)


if __name__=="__main__":
    main()
