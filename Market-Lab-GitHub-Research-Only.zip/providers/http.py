import json
import re
import time
from threading import Lock
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


class ProviderError(ValueError):
    def __init__(self, message, *, kind="provider", host=None, status=None, retry_after=0):
        super().__init__(message)
        self.kind,self.host,self.status,self.retry_after=kind,host,status,retry_after


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


OPENER = build_opener(ProxyHandler({}), NoRedirect())
PUBLIC_HOSTS = frozenset({
    "api.upbit.com", "api.exchange.coinbase.com", "www.nasdaqtrader.com",
    "www.alphavantage.co", "apis.data.go.kr", "www.federalreserve.gov",
    "hn.algolia.com", "fred.stlouisfed.org", "data.sec.gov", "www.sec.gov",
    "opendart.fss.or.kr", "mempool.space", "api.github.com",
})
PUBLIC_PATHS = {
    "api.upbit.com":r"/v1/(?:market/all|ticker|orderbook|trades/ticks|candles/(?:days|minutes/(?:1|5|60)))",
    "api.exchange.coinbase.com":r"/products(?:/[A-Z0-9]+-USD(?:/(?:candles|ticker|book|stats|trades))?)?",
    "www.nasdaqtrader.com":r"/dynamic/SymDir/(?:nasdaqlisted|otherlisted)\.txt",
    "www.alphavantage.co":r"/query",
    "apis.data.go.kr":r"/1160100/(?:GetStockSecuritiesInfoService_V2/getStockPriceInfo_V2|GetSecuritiesProductInfoService_V2/getETFPriceInfo_V2|GetMarketIndexInfoService_V2/getStockMarketIndex_V2)",
    "www.federalreserve.gov":r"/(?:feeds/press_all\.xml|newsevents/pressreleases/[a-z0-9]+\.htm)",
    "hn.algolia.com":r"/api/v1/search_by_date",
    "fred.stlouisfed.org":r"/graph/fredgraph\.csv",
    "data.sec.gov":r"/(?:submissions|api/xbrl/companyfacts)/CIK[0-9]{10}\.json",
    "www.sec.gov":r"/files/company_tickers\.json",
    "opendart.fss.or.kr":r"/api/(?:corpCode\.xml|list\.json|fnlttSinglAcnt\.json)",
    "mempool.space":r"/api/blocks",
    "api.github.com":r"/repos/[A-Za-z0-9-]{1,39}/[A-Za-z0-9_.-]{1,100}/actions/runs/[1-9][0-9]{0,19}",
}
GAP = {"api.upbit.com": 0.25, "api.exchange.coinbase.com": 0.25, "data.sec.gov": 0.25,
       "www.nasdaqtrader.com": 0.3, "apis.data.go.kr": 0.25}
_last = {}
_cooldown = {}
CRYPTO_HOSTS = frozenset({"api.upbit.com","api.exchange.coinbase.com"})
_lock = Lock()


def request(url, params=None, *, timeout=8, max_bytes=4_000_000, contact=None, local_body=None):
    details = urlsplit(url)
    local = details.netloc == "127.0.0.1:11434" and details.scheme == "http"
    if local:
        if details.path not in ("/api/tags", "/api/ps", "/api/generate") or details.query or details.fragment:
            raise ProviderError("지원하지 않는 로컬 AI 경로입니다.")
        if (details.path == "/api/generate") != (local_body is not None):
            raise ProviderError("지원하지 않는 로컬 AI 요청입니다.")
    elif (details.scheme != "https" or details.netloc not in PUBLIC_HOSTS
          or local_body is not None or details.query or details.fragment
          or not re.fullmatch(PUBLIC_PATHS[details.netloc],details.path)):
        raise ProviderError("지원하지 않는 공개 데이터 주소입니다.")
    if details.netloc=="www.alphavantage.co" and (params or {}).get("function")!="TIME_SERIES_DAILY":
        raise ProviderError("미국 시세는 무료 지원 일봉 경로만 허용합니다.")
    host = details.hostname
    if host in GAP:
        while True:
            with _lock:
                clock=time.monotonic()
                if clock<_cooldown.get(host,0):
                    raise ProviderError(f"{host} 공개 요청 한도 대기",kind="http",host=host,status=429,
                                        retry_after=int(_cooldown[host]-clock)+1)
                delay=_last.get(host,0)+GAP[host]-clock
                if delay<=0:
                    _last[host]=clock
                    break
            time.sleep(delay)
    headers = {"User-Agent": f"LocalMarketLab/1.0 ({contact})" if contact else "LocalMarketLab/1.0",
               "Accept": "application/json, text/plain, application/xml, text/csv, */*"}
    if local_body is not None:
        headers["Content-Type"] = "application/json"
    outgoing = Request(url + ("?" + urlencode(params) if params else ""),
                       data=None if local_body is None else json.dumps(local_body).encode(),
                       headers=headers, method="GET" if local_body is None else "POST")
    try:
        with OPENER.open(outgoing, timeout=timeout) as response:
            body = response.read(max_bytes + 1)
            if len(body) > max_bytes:
                raise ProviderError(f"{host} 응답 크기 제한을 초과했습니다.")
            return body
    except HTTPError as exc:
        value=exc.headers.get("Retry-After","")
        delay=int(value) if value.isascii() and value.isdecimal() and len(value)<8 else 0
        exc.close()
        if host in CRYPTO_HOSTS and exc.code in (418,429):
            delay=max(delay,15)
            with _lock:
                _cooldown[host]=max(_cooldown.get(host,0),time.monotonic()+delay)
        raise ProviderError(f"{host} HTTP {exc.code}",kind="http",host=host,status=exc.code,retry_after=delay) from None
    except (URLError, OSError) as exc:
        reason=exc.reason if isinstance(exc,URLError) else exc
        if isinstance(reason,TimeoutError):
            raise ProviderError(f"{host} 응답 시간이 초과되었습니다.",kind="timeout",host=host) from None
        raise ProviderError(f"{host} 연결에 실패했습니다.",kind="connection",host=host) from None


def fetch_json(url, params=None, **kwargs):
    try:
        return json.loads(request(url, params, **kwargs))
    except (ValueError, UnicodeError) as exc:
        if isinstance(exc, ProviderError):
            raise
        host=urlsplit(url).hostname
        raise ProviderError(f"{host} JSON 응답을 읽을 수 없습니다.",kind="json",host=host) from None
