import csv
from datetime import UTC, date, datetime, time, timedelta, timezone
import io
import os
import re

from core.models import Asset, Bar, DELAYED, HISTORY, LIVE, TEST, link, now, number, timestamp
from providers.http import ProviderError, fetch_json, request

UPBIT = "https://api.upbit.com/v1"
COINBASE = "https://api.exchange.coinbase.com/products"
ALPHA = "https://www.alphavantage.co/query"
FSC = "https://apis.data.go.kr/1160100"
FRED = "https://fred.stlouisfed.org"
KR_ROUTES = {
    "주식": ("GetStockSecuritiesInfoService_V2/getStockPriceInfo_V2", "15094808"),
    "ETF": ("GetSecuritiesProductInfoService_V2/getETFPriceInfo_V2", "15094806"),
    "지수": ("GetMarketIndexInfoService_V2/getStockMarketIndex_V2", "15094807"),
}
FRAMES = {"1m": 60, "5m": 300, "1h": 3600, "1d": 86400, "1w": 604800}
FRED_INDICES = {"SP500": "S&P 500", "NASDAQCOM": "NASDAQ Composite", "DJIA": "Dow Jones Industrial Average"}


def starter_assets():
    base = [
        Asset("KR:005930","KR","005930","삼성전자","KOSPI","KRW","주식","FSC"),
        Asset("KR:000660","KR","000660","SK하이닉스","KOSPI","KRW","주식","FSC"),
        Asset("KR:247540","KR","247540","에코프로비엠","KOSDAQ","KRW","주식","FSC"),
        Asset("KR:069500","KR","069500","KODEX 200","KRX","KRW","ETF","FSC"),
        Asset("KR:KOSPI","KR","KOSPI","코스피","KRX","KRW","지수","FSC"),
        Asset("KR:KOSDAQ","KR","KOSDAQ","코스닥","KRX","KRW","지수","FSC"),
        Asset("US:AAPL","US","AAPL","Apple","NASDAQ","USD","주식","Alpha Vantage",cik="0000320193"),
        Asset("US:MSFT","US","MSFT","Microsoft","NASDAQ","USD","주식","Alpha Vantage",cik="0000789019"),
        Asset("US:IBM","US","IBM","IBM","NYSE","USD","주식","Alpha Vantage",cik="0000051143"),
        Asset("US:SPY","US","SPY","SPDR S&P 500 ETF","NYSE Arca","USD","ETF","Alpha Vantage"),
    ]
    for symbol, name in FRED_INDICES.items():
        base.append(Asset("US:"+symbol,"US",symbol,name,"미국 지수","USD","지수","FRED"))
    for coin in ("BTC","ETH","SOL","XRP"):
        base.extend([
            Asset(f"CRYPTO:KRW-{coin}","CRYPTO",f"KRW-{coin}",coin,"Upbit","KRW","현물","Upbit"),
            Asset(f"CRYPTO:{coin}-USD","CRYPTO",f"{coin}-USD",coin,"Coinbase Exchange","USD","현물","Coinbase"),
        ])
    return base


def upbit_catalog():
    for item in fetch_json(UPBIT + "/market/all", {"is_details": "true"}):
        symbol = item["market"]
        if symbol.startswith("KRW-"):
            warning = item.get("market_warning") == "CAUTION" or item.get("market_event", {}).get("warning")
            state = "유의" if warning else "목록 등재"
            yield Asset("CRYPTO:"+symbol,"CRYPTO",symbol,item["korean_name"],"Upbit","KRW","현물","Upbit",state)


def coinbase_catalog():
    for item in fetch_json(COINBASE):
        if item["quote_currency"] == "USD":
            symbol = item["id"]
            disabled = item.get("trading_disabled") or item.get("cancel_only") or item.get("auction_mode")
            state = "목록 등재" if item["status"] == "online" and not disabled else "거래 제한"
            yield Asset("CRYPTO:"+symbol,"CRYPTO",symbol,item.get("display_name", symbol),
                        "Coinbase Exchange","USD","현물","Coinbase",state)


def nasdaq_catalog(source, store):
    file = "nasdaqlisted" if source == "NASDAQ" else "otherlisted"
    url = "https://www.nasdaqtrader.com/dynamic/SymDir/" + file + ".txt"
    content = request(url).decode("utf-8-sig")
    raw = csv.DictReader(io.StringIO(content), delimiter="|")
    old_ciks = {item["id"]: item["cik"] for item in store.search("US", limit=20000) if item.get("cik")}
    for item in raw:
        symbol = item.get("Symbol" if source == "NASDAQ" else "ACT Symbol", "")
        exchange_code = item.get("Exchange")
        if (not re.fullmatch(r"[A-Z0-9.^_-]{1,15}", symbol) or item.get("Test Issue") == "Y"
                or (source != "NASDAQ" and exchange_code not in {"N","A","P"})):
            continue
        exchange = source if source == "NASDAQ" else {"N":"NYSE","A":"NYSE American","P":"NYSE Arca"}[exchange_code]
        state = "목록 등재" if item.get("Financial Status", "N") == "N" else "재무 상태 주의"
        asset_id = "US:"+symbol
        yield Asset(asset_id,"US",symbol,item["Security Name"],exchange,"USD",
                    "ETF" if item.get("ETF") == "Y" else "주식","Alpha Vantage",state,old_ciks.get(asset_id,""))


def fsc_rows(kind, **params):
    key = os.getenv("KR_FSC_KEY")
    if not key:
        raise ProviderError("국내 시세 수집에는 KR_FSC_KEY가 필요합니다. CSV로도 불러올 수 있습니다.")
    route, code = KR_ROUTES[kind]
    access_note=f"공공데이터포털에서 금융위원회 {kind} 조회 서비스({code})의 활용 신청과 승인 상태를 확인하세요."
    try:
        payload = fetch_json(FSC + "/" + route, {"serviceKey": key, "resultType":"json", **params})
    except ProviderError as exc:
        if exc.status in (401,403):
            raise ProviderError(access_note,kind=exc.kind,host=exc.host,status=exc.status) from None
        raise
    response = payload.get("response", {})
    if response.get("header", {}).get("resultCode") not in ("00", "0", 0):
        raise ProviderError(access_note)
    body = response.get("body") or {}
    data = (body.get("items") or {}).get("item", []) if isinstance(body.get("items") or {}, dict) else []
    return ([data] if isinstance(data, dict) else data), int(body.get("totalCount", 0))


def fsc_catalog(kind):
    for offset in range(1, 8):
        day = (date.today()-timedelta(days=offset)).strftime("%Y%m%d")
        rows, count = fsc_rows(kind, basDt=day, pageNo=1, numOfRows=1000)
        if rows:
            for page in range(2, min(20, (count+999)//1000)+1):
                rows += fsc_rows(kind, basDt=day, pageNo=page, numOfRows=1000)[0]
            break
    for row in rows:
        symbol = str(row.get("srtnCd", "")).removeprefix("A")
        exchange = str(row.get("mrktCtg", "KRX"))
        if re.fullmatch("[0-9A-Z]{6}", symbol) and (kind == "ETF" or exchange in ("KOSPI","KOSDAQ")):
            yield Asset("KR:"+symbol,"KR",symbol,row["itmsNm"],exchange,"KRW",kind,"FSC","일별 목록 등재")


def pack(bars, source, url, quality, adjustment="미확인", allow_empty=False):
    unique = {bar.time: bar.json() for bar in bars}
    if not unique and not allow_empty:
        raise ProviderError("완료된 유효 OHLCV 데이터가 없습니다.")
    return {"bars": [unique[t] for t in sorted(unique)], "source":source, "url":link(url),
            "quality":quality, "retrieved":now(), "adjustment":adjustment}


def us_close(day):
    march = date(day.year, 3, 1)
    november = date(day.year, 11, 1)
    dst_start = march + timedelta(days=(6-march.weekday())%7+7)
    dst_end = november + timedelta(days=(6-november.weekday())%7)
    return datetime.combine(day,time(20 if dst_start <= day < dst_end else 21),UTC)


def weekly(bars):
    groups = {}
    for bar in bars:
        dt = datetime.fromisoformat(bar.time) - timedelta(microseconds=1)
        groups.setdefault(dt.isocalendar()[:2], []).append(bar)
    current_week = datetime.now(UTC).isocalendar()[:2]
    result = []
    for key, items in sorted(groups.items()):
        if key >= current_week:
            continue
        volume = sum(x.volume for x in items) if all(x.volume is not None for x in items) else None
        turnover = sum(x.turnover for x in items) if all(x.turnover is not None for x in items) else None
        result.append(Bar.make(items[-1].time,items[0].open,max(b.high for b in items),
                               min(b.low for b in items),items[-1].close,volume,turnover))
    return result


def fred_rows(series):
    raw = request(FRED + "/graph/fredgraph.csv", {"id":series})
    return [(date.fromisoformat(row[0]), float(row[1])) for row in list(
        csv.reader(io.StringIO(raw.decode("utf-8-sig"))))[1:] if len(row) >= 2 and row[1] not in ("",".")]


def market_bars(asset, frame, store):
    symbol, source = asset["symbol"], asset["provider"]
    if frame not in FRAMES:
        raise ValueError("시간 단위를 확인하세요.")
    seconds = FRAMES["1d" if frame == "1w" else frame]
    bars = []
    utc_now = datetime.now(UTC)
    quality, adjustment = HISTORY, "해당 없음"
    if source == "Upbit":
        period = {60:"minutes/1",300:"minutes/5",3600:"minutes/60",86400:"days"}[seconds]
        endpoint = "/candles/" + period
        for row in fetch_json(UPBIT + endpoint, {"market":symbol,"count":200}):
            end = datetime.fromisoformat(row["candle_date_time_utc"]).replace(tzinfo=UTC)+timedelta(seconds=seconds)
            if end <= utc_now:
                bars.append(Bar.make(end.isoformat(),row["opening_price"],row["high_price"],row["low_price"],
                                     row["trade_price"],row["candle_acc_trade_volume"],row["candle_acc_trade_price"]))
        url = "https://docs.upbit.com/kr/reference/list-candles-" + ("days" if seconds == 86400 else "minutes")
    elif source == "Coinbase":
        end_time = utc_now.replace(microsecond=0)
        start_time = end_time-timedelta(seconds=seconds*250)
        for epoch, lo, hi, op, cl, vol in fetch_json(COINBASE + "/" + symbol + "/candles",
            {"granularity":seconds,"start":start_time.isoformat(),"end":end_time.isoformat()}):
            start = datetime.fromtimestamp(epoch,UTC)
            end = start+timedelta(seconds=seconds)
            if start >= start_time and end <= utc_now:
                bars.append(Bar.make(end.isoformat(),op,hi,lo,cl,vol))
        url = "https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles"
    elif frame not in ("1d","1w"):
        raise ProviderError("이 출처는 일봉·주봉을 지원합니다. 다른 시간 단위는 CSV로 불러올 수 있습니다.")
    elif source == "FSC":
        kind = asset["kind"]
        _, code = KR_ROUTES[kind]
        query = {"idxNm":("코스피" if symbol == "KOSPI" else "코스닥")} if kind == "지수" else {"likeSrtnCd":symbol}
        rows, _ = fsc_rows(kind, pageNo=1,numOfRows=260,beginBasDt=(utc_now.date()-timedelta(days=365)).strftime("%Y%m%d"),**query)
        for row in rows:
            if kind != "지수" and str(row.get("srtnCd","")).removeprefix("A") != symbol:
                continue
            day = datetime.strptime(row["basDt"],"%Y%m%d").date()
            end = datetime.combine(day,time(6,30),UTC)
            names = ("mkp","hipr","lopr","clpr") if kind != "지수" else ("opnprcIdx","hgprcIdx","lwprcIdx","clpr")
            values = [row.get(k) for k in names]
            if end <= utc_now and all(values) and all(float(v)>0 for v in values):
                bars.append(Bar.make(end.isoformat(),*values,row.get("trqu"),row.get("trPrc")))
        url = f"https://www.data.go.kr/data/{code}/openapi.do"
        quality, adjustment = DELAYED, "원시가격" if kind != "지수" else "지수"
    elif source == "Alpha Vantage":
        key = os.getenv("ALPHA_VANTAGE_KEY")
        if not key:
            raise ProviderError("미국 주식 시세 수집에는 ALPHA_VANTAGE_KEY가 필요합니다. CSV로도 불러올 수 있습니다.")
        if not store.charge("alpha:"+utc_now.date().isoformat(),25):
            raise ProviderError("미국 시세의 일일 25회 한도에 도달했습니다.")
        raw = fetch_json(ALPHA, {"function":"TIME_SERIES_DAILY","symbol":symbol,"outputsize":"compact","apikey":key})
        if not isinstance(raw,dict) or not raw.get("Time Series (Daily)"):
            raw=raw if isinstance(raw,dict) else {}
            note=str(raw.get("Note") or raw.get("Information") or "").lower()
            if any(phrase in note for phrase in ("rate limit","requests per day","call frequency")):
                raise ProviderError("Alpha Vantage 공급자가 현재 호출을 제한했습니다.",kind="http",
                                    host="www.alphavantage.co",status=429)
            if "premium" in note:
                raise ProviderError("Alpha Vantage 무료 일봉 경로에서 이 요청이 지원되지 않습니다.",kind="provider",
                                    host="www.alphavantage.co")
            raise ProviderError("Alpha Vantage가 이 심볼의 일봉을 반환하지 않았습니다. 심볼과 무료 제공 범위를 확인하세요.",
                                kind="provider",host="www.alphavantage.co")
        for day, row in raw["Time Series (Daily)"].items():
            end = us_close(date.fromisoformat(day))
            if end <= utc_now:
                bars.append(Bar.make(end.isoformat(),*[row[str(i)+". "+k] for i,k in
                    enumerate(("open","high","low","close","volume"),1)]))
        url = "https://www.alphavantage.co/documentation/#daily"
        quality, adjustment = DELAYED, "원시가격"
    elif source == "FRED":
        raise ProviderError("FRED 지수는 종가 관측값으로 제공됩니다. 경제 지표 메뉴에서 확인하세요.")
    else:
        raise ProviderError("이 종목의 시세는 CSV로 불러올 수 있습니다.")
    bars.sort(key=lambda b:b.time)
    return pack(weekly(bars) if frame == "1w" else bars,source,url,quality,adjustment)


def ticker_observation(asset, price, at, received):
    traded=timestamp(at)
    if traded>received:
        raise ValueError("공개 시세 시각이 로컬 수신 시각보다 늦습니다.")
    return {"asset":asset["id"],"source":asset["provider"],"price":number(price,1e-12),
            "time":traded,"retrieved":received}


def upbit_tickers(assets):
    by_symbol={asset["symbol"]:asset for asset in assets}
    rows=fetch_json(UPBIT+"/ticker",{"markets":",".join(by_symbol)},timeout=5,max_bytes=200_000)
    if not isinstance(rows,list):
        raise ProviderError("업비트 공개 시세 응답 형식을 확인하세요.",kind="json",host="api.upbit.com")
    received=now()
    observed={}
    for row in rows:
        asset=by_symbol.get(row.get("market")) if isinstance(row,dict) else None
        if not asset:
            continue
        try:
            at=datetime.fromtimestamp(row["trade_timestamp"]/1000,UTC).isoformat()
            observed[asset["id"]]=ticker_observation(asset,row["trade_price"],at,received)
        except (ValueError,KeyError,TypeError,ArithmeticError,OSError):
            continue
    return list(observed.values())


def public_ticker(asset):
    if asset["provider"]=="Upbit":
        observations=upbit_tickers([asset])
        if observations:
            return observations[0]
        raise ProviderError("업비트 공개 시세에서 확인 가능한 종목이 없습니다.",host="api.upbit.com")
    if asset["provider"]!="Coinbase":
        raise ProviderError("공개 최근 체결가를 지원하지 않는 제공처입니다.")
    row=fetch_json(COINBASE+"/"+asset["symbol"]+"/ticker",timeout=5,max_bytes=40_000)
    try:
        return ticker_observation(asset,row["price"],row["time"],now())
    except (ValueError,KeyError,TypeError) as exc:
        raise ProviderError("Coinbase 공개 시세의 가격 또는 시각을 확인할 수 없습니다.",
                            kind="json",host="api.exchange.coinbase.com") from exc


def quote(asset):
    source, symbol = asset["provider"], asset["symbol"]
    trades = []
    if source == "Upbit":
        price = fetch_json(UPBIT+"/ticker", {"markets":symbol})[0]
        book = fetch_json(UPBIT+"/orderbook", {"markets":symbol})[0]
        top = book["orderbook_units"][0]
        book_id = str(book["timestamp"])
        raw = fetch_json(UPBIT+"/trades/ticks", {"market":symbol,"count":8})
        trades = [{"time":datetime.fromtimestamp(t["timestamp"]/1000,UTC).isoformat(),
                   "price":number(t["trade_price"],1e-12),"size":number(t["trade_volume"])} for t in raw]
        values = {"price":price["trade_price"],"open":price["opening_price"],"high":price["high_price"],
                  "low":price["low_price"],"volume":price["acc_trade_volume_24h"],
                  "turnover":price["acc_trade_price_24h"]}
        mark = datetime.fromtimestamp(price["trade_timestamp"]/1000,UTC).isoformat()
        bid, ask, bid_size, ask_size = [top[k] for k in ("bid_price","ask_price","bid_size","ask_size")]
        source_url = "https://docs.upbit.com/kr/reference/list-tickers"
        change = price["signed_change_rate"]*100
    elif source == "Coinbase":
        url = COINBASE+"/"+symbol
        price = fetch_json(url+"/ticker")
        top = fetch_json(url+"/book", {"level":1})
        book_id = str(top["sequence"])
        data = fetch_json(url+"/stats")
        raw = fetch_json(url+"/trades", {"limit":8})
        trades = [{"time":timestamp(t["time"]),"price":number(t["price"],1e-12),"size":number(t["size"])} for t in raw]
        values = {"price":price["price"],"open":data["open"],"high":data["high"],"low":data["low"],"volume":data["volume"]}
        mark = price["time"]
        bid,bid_size,_ = top["bids"][0]
        ask,ask_size,_ = top["asks"][0]
        source_url = "https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-ticker"
        change = (float(values["price"])/float(values["open"])-1)*100
    else:
        raise ProviderError("이 제공처의 실시간 호가를 사용할 수 없습니다.")
    result = {k:number(v) for k,v in values.items()}
    result.update(bid=number(bid,1e-12),ask=number(ask,1e-12),bid_size=number(bid_size),
                  ask_size=number(ask_size),time=timestamp(mark),retrieved=now(),url=source_url,
                  quality=LIVE, source=source,trades=trades,change=change,book_id=book_id)
    if result["ask"] < result["bid"]:
        raise ProviderError("호가 가격이 역전되었습니다. 다음 스냅샷을 기다립니다.")
    result["spread_bps"] = (result["ask"]-result["bid"])/((result["ask"]+result["bid"])/2)*10000
    return result


def import_csv(payload):
    if payload.get("frame") not in FRAMES or payload.get("quality") not in (HISTORY, TEST):
        raise ValueError("CSV의 시간 단위와 자료 구분을 확인하세요.")
    url = link(payload.get("url",""))
    raw = payload.get("csv","")
    adjustment = payload.get("adjustment")
    if not isinstance(raw,str) or len(raw)>900_000 or adjustment not in ("원시가격","조정 OHLC","해당 없음","미확인"):
        raise ValueError("CSV 크기 또는 가격 조정 구분을 확인하세요.")
    reader = csv.DictReader(io.StringIO(raw.lstrip("\ufeff")))
    if not set(("time","open","high","low","close")).issubset(reader.fieldnames or ()):
        raise ValueError("CSV 필수 열은 time,open,high,low,close입니다.")
    bars = []
    seen = set()
    for row in reader:
        point = row["time"]
        if len(point)==10 and payload["frame"] in ("1d","1w"):
            point += "T23:59:59+00:00"
        bar = Bar.make(point,row["open"],row["high"],row["low"],row["close"],
                       row.get("volume") or None,row.get("turnover") or None)
        if bar.time in seen or (payload["quality"] != TEST and bar.time > now()):
            raise ValueError("CSV에 중복 또는 미래 시각이 있습니다.")
        seen.add(bar.time)
        bars.append(bar)
    return pack(bars,"CSV",url,payload["quality"],adjustment)
