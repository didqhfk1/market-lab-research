from decimal import Decimal, InvalidOperation
import json
import re
from uuid import uuid4

from config.settings import MARKETS
from core.models import now
from database.audit import append
from database.store import encode

LEGACY = "legacy"
CURRENCIES = {"KR":("KRW",),"US":("USD",),"CRYPTO":("KRW","USD")}


def active(conn):
    return conn.execute("SELECT * FROM auto_sessions WHERE ended IS NULL").fetchone()


def active_id(store):
    rows = store.query("SELECT id FROM auto_sessions WHERE ended IS NULL")
    return rows[0]["id"] if rows else LEGACY


def money(value, currency):
    if type(value) not in (int,float) or currency not in ("KRW","USD"):
        raise ValueError("원화 또는 달러의 가상 금액을 숫자로 입력하세요.")
    try:
        amount = Decimal(str(value))
        limit = Decimal(10**12 if currency=="KRW" else 10**9)
        unit = Decimal(1) if currency=="KRW" else Decimal(".01")
        if not amount.is_finite() or not unit<=amount<=limit or amount.quantize(unit)!=amount:
            raise ValueError("원화는 1원 이상 정수, 달러는 0.01달러 이상 소수점 둘째 자리까지 입력하세요.")
        return amount
    except InvalidOperation:
        raise ValueError("가상 금액을 확인하세요.") from None


def split(amount, currency, count):
    if not count:
        return []
    unit = Decimal(1) if currency=="KRW" else Decimal(".01")
    units,remainder = divmod(int(amount/unit),count)
    return [unit*(units+int(i<remainder)) for i in range(count)]


def _start(conn, settings, at, state):
    region_setting = settings["markets"]
    amount = {currency:money(settings["initial_"+currency.lower()],currency) for currency in ("KRW","USD")}
    ident = uuid4().hex
    research = {"markets":region_setting,"model":settings["model"],"model_version":"연결 후 분석 기록에 저장",
                "strategy_version":"auto-2","strategy_ids":settings["strategy_ids"],
                "fee_bps":settings["fee_bps"],"spread_bps":settings["spread_bps"],
                "slippage_bps":settings["slippage_bps"]}
    conn.execute("INSERT INTO auto_sessions VALUES(?,?,?,?,?,?,?,?)",
                 (ident,at,at if state=="running" else None,None,state,str(amount["KRW"]),str(amount["USD"]),encode(research)))
    for currency,value in amount.items():
        pools = [(r,d) for r in MARKETS if r in region_setting and currency in CURRENCIES[r] for d in ("LONG","SHORT")]
        for (region,direction),allocation in zip(pools,split(value,currency,len(pools))):
            conn.execute("INSERT INTO auto_session_accounts VALUES(?,?,?,?,?,?,?,?)",
                         (ident,region,direction,currency,str(allocation),"0",str(allocation),"0"))
    append(conn,"simulation_session",{"id":ident,"state":state,"initial":{k:str(v) for k,v in amount.items()},
                                      "settings":research},at)
    return ident


def _close(conn, session, state, at):
    from simulation.automatic import finalize_in
    ident = session["id"] if session else LEGACY
    finalize_in(conn,ident,at)
    if session:
        conn.execute("UPDATE auto_sessions SET state=?,ended=? WHERE id=?",(state,at,ident))
    append(conn,"simulation_session",{"id":ident,"state":state},at)


def transition(store, action, params):
    """Save operating state, capital and its audit event in the same transaction."""
    modes = {
        "start":{"mode":"auto_paper","enabled":True,"paused":False,"operator":"running"},
        "resume":{"mode":"auto_paper","enabled":True,"paused":False,"operator":"running"},
        "pause":{"paused":True,"operator":"paused"},
        "end":{"mode":"analysis","enabled":True,"paused":False,"operator":"idle"},
        "stop":{"mode":"analysis","enabled":False,"paused":True,"operator":"stopped"},
        "reset":{"mode":"analysis","enabled":True,"paused":False,"operator":"idle"},
    }
    allowed = {"action","initial_krw","initial_usd","markets"} if action in ("start","reset") else (
        {"action","currency","amount","session","operation_id"} if action=="deposit" else {"action"})
    if action not in (*modes,"deposit") or set(params)-allowed:
        raise ValueError("모의투자 세션의 작업 및 입력을 확인하세요.")
    at = now()
    with store.tx() as conn:
        cfg = store.settings(conn)
        session = active(conn)
        if action=="deposit":
            if not session:
                raise ValueError("가상 자산을 추가하려면 먼저 세션을 시작하세요.")
            if "session" in params and params["session"]!=session["id"]:
                raise ValueError("가상 세션이 바뀌었습니다. 화면을 새로고침한 뒤 다시 확인하세요.")
            currency = params.get("currency")
            value = money(params.get("amount"),currency)
            unit = Decimal(1) if currency=="KRW" else Decimal(".01")
            deposit = {"id":session["id"],"currency":currency,"amount":str(value.quantize(unit))}
            if "operation_id" in params:
                operation_id = params["operation_id"]
                if not isinstance(operation_id,str) or not re.fullmatch(r"[a-f0-9]{32}",operation_id):
                    raise ValueError("가상 자산 추가 요청의 식별자를 확인하세요.")
                deposit["operation_id"] = operation_id
                previous = conn.execute("""SELECT body FROM audit_ledger WHERE action='simulation_capital'
                    AND json_extract(body,'$.id')=? AND json_extract(body,'$.operation_id')=? LIMIT 1""",
                    (session["id"],operation_id)).fetchone()
                if previous:
                    if json.loads(previous["body"])!=deposit:
                        raise ValueError("이미 처리된 요청입니다. 가상 잔액을 먼저 확인하세요.")
                    return cfg,session["id"]
            rows = conn.execute("""SELECT * FROM auto_session_accounts
                WHERE session=? AND currency=? ORDER BY region,direction""",(session["id"],currency)).fetchall()
            if not rows:
                raise ValueError("이 세션에서 사용하는 통화를 선택하세요.")
            limit = Decimal(10**12 if currency=="KRW" else 10**9)
            if sum(Decimal(row["initial"])+Decimal(row["added"]) for row in rows)+value>limit:
                raise ValueError("이 세션의 가상 자산 상한을 초과했습니다.")
            for row,allocation in zip(rows,split(value,currency,len(rows))):
                conn.execute("""UPDATE auto_session_accounts SET added=?,cash=?
                    WHERE session=? AND region=? AND direction=? AND currency=?""",
                    (str(Decimal(row["added"])+allocation),str(Decimal(row["cash"])+allocation),
                     session["id"],row["region"],row["direction"],currency))
            append(conn,"simulation_capital",deposit,at)
            return cfg,session["id"]
        if action=="resume" and cfg["operator"]!="paused":
            raise ValueError("일시정지한 세션만 재개할 수 있습니다.")
        if action=="pause" and not (cfg["enabled"] and not cfg["paused"] and cfg["mode"]=="auto_paper"):
            raise ValueError("자동 연구가 실행 중일 때 일시정지할 수 있습니다.")
        if action=="start" and session and session["state"]!="waiting":
            return cfg,session["id"]
        changes = {}
        if action in ("start","reset"):
            for currency in ("KRW","USD"):
                field = "initial_"+currency.lower()
                if field in params:
                    value = money(params[field],currency)
                    changes[field] = int(value) if currency=="KRW" else float(value)
            if "markets" in params:
                changes["markets"] = params["markets"]
            if not changes.get("markets",cfg["markets"]):
                raise ValueError("연구 시장을 한 곳 이상 선택하세요.")
        if action in ("start","reset","resume") and not verified_in(conn):
            raise ValueError("가상 원장을 검증하지 못했습니다. 백업을 확인하세요.")
        ending = action in ("end","stop","reset") or (action=="start" and session and
                  any(cfg[key]!=value for key,value in changes.items()))
        if ending:
            _close(conn,session,"stopped" if action=="stop" else "ended",at)
            session = None
        cfg = store.configure_in(conn,modes[action] | changes)
        ident = session["id"] if session else None
        if action in ("start","resume","reset"):
            if session is None:
                if action!="reset" and not ending:
                    from simulation.automatic import finalize_in
                    finalize_in(conn,LEGACY,at)
                ident = _start(conn,cfg,at,"waiting" if action=="reset" else "running")
            else:
                conn.execute("UPDATE auto_sessions SET state='running',started=COALESCE(started,?) WHERE id=?",
                             (at,ident))
                append(conn,"simulation_session",{"id":ident,"state":"running"},at)
        if action=="pause" and ident:
            conn.execute("UPDATE auto_sessions SET state='paused' WHERE id=?",(ident,))
            append(conn,"simulation_session",{"id":ident,"state":"paused"},at)
        return cfg,ident


def verified_in(conn):
    try:
        return _matches_accounts(conn)
    except (InvalidOperation,TypeError,ValueError,KeyError):
        return False


def _matches_accounts(conn):
    from simulation.automatic import CLOSED, FROZEN, OPEN
    amounts = {}
    for row in conn.execute("SELECT session,body FROM auto_cycles WHERE session<>? AND state IN (?,?,?)",
                            (LEGACY,CLOSED,FROZEN,OPEN)):
        trade = json.loads(row["body"])
        scope = (row["session"],trade["region"],trade["direction"],trade["currency"])
        result,exposure = amounts.get(scope,(Decimal(0),Decimal(0)))
        if trade["state"]==CLOSED:
            result += Decimal(trade["realized"])
        else:
            exposure += Decimal(trade["notional"])+Decimal(trade["entry_fee"])
        amounts[scope] = result,exposure
    for row in conn.execute("SELECT * FROM auto_session_accounts"):
        key = tuple(row[k] for k in ("session","region","direction","currency"))
        result,exposure = amounts.pop(key,(Decimal(0),Decimal(0)))
        entries = [Decimal(row[k]) for k in ("initial","added","cash","realized")]
        initial,added,cash,recorded = entries
        if (not all(v.is_finite() for v in entries) or min(initial,added,cash)<0 or
                abs(result-recorded)>Decimal("1e-12") or abs(initial+added+result-exposure-cash)>Decimal("1e-12")):
            return False
    for session in conn.execute("SELECT * FROM auto_sessions"):
        regions = json.loads(session["body"])["markets"]
        for currency in ("KRW","USD"):
            actual = { (row["region"],row["direction"]):Decimal(row["initial"]) for row in conn.execute(
                "SELECT region,direction,initial FROM auto_session_accounts WHERE session=? AND currency=?",
                (session["id"],currency))}
            expected = [(r,d) for r in MARKETS if r in regions and currency in CURRENCIES[r] for d in ("LONG","SHORT")]
            if actual!=dict(zip(expected,split(Decimal(session["currency_"+currency.lower()]),currency,len(expected)))):
                return False
    return not amounts


def details(conn, session):
    item = dict(session) | json.loads(session["body"])
    item.pop("body")
    item["reports"] = [r["name"] for r in conn.execute(
        "SELECT name FROM auto_session_reports WHERE session=? ORDER BY name DESC LIMIT 15",(session["id"],))]
    item["holdings"] = conn.execute("SELECT COUNT(*) FROM auto_cycles WHERE session=? AND state='가상 보유'",
                                   (session["id"],)).fetchone()[0]
    return item


def attach_report(store, filename, session_id=None):
    with store.tx() as conn:
        session = active(conn)
        ident = session_id or (session["id"] if session else None)
        if ident:
            conn.execute("""INSERT OR IGNORE INTO auto_session_reports
                SELECT id,? FROM auto_sessions WHERE id=?""",(filename,ident))
