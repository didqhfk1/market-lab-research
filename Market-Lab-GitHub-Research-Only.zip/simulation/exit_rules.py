"""Shared, paper-only exit policy and separate recording schedule."""

from decimal import Decimal
from types import MappingProxyType


FIXED_EXIT_BARS = MappingProxyType({"CRYPTO": 12, "KR": 5, "US": 5})
INTERIM_INTERVAL_BARS = MappingProxyType({"CRYPTO": 3, "KR": 1, "US": 1})
POLICY_VERSION = "fixed-completed-bars-v1"


def decide_exit(direction, signal, collateral, move_ratio, completed_bars, horizon_bars):
    if not collateral:
        return "exit.collateral", "가상 담보 소진"
    if signal and signal != direction:
        return "exit.opposite", "반대 신호"
    if horizon_bars is not None and completed_bars >= horizon_bars:
        return "exit.horizon", "보유기간 경과"
    if move_ratio <= Decimal("-.04") or move_ratio >= Decimal(".08"):
        return "exit.price_move", "연구 손익 한도"
    return "hold.no_exit", "청산 조건 미충족"


def policy_view(region):
    return {"version": POLICY_VERSION, "fixed_exit_bars": FIXED_EXIT_BARS[region],
            "interim_interval_bars": INTERIM_INTERVAL_BARS[region],
            "frame": "5m" if region == "CRYPTO" else "1d",
            "settings_location": "simulation/exit_rules.py",
            "unlimited_mode": "격리된 역사 실험 전용"}
