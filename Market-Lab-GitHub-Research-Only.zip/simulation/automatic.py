from datetime import UTC, datetime, timedelta, timezone
from contextlib import closing
from decimal import Decimal
import json
import os
import re

from core.models import DELAYED, HISTORY, now
from database.audit import append
from database.learning import Learning, digest
from database.store import encode
from risk.checks import decimal
from simulation import sessions
from simulation.exit_rules import FIXED_EXIT_BARS, INTERIM_INTERVAL_BARS, POLICY_VERSION, decide_exit, policy_view

MODE = "auto_paper"
QUEUED, OPEN, CLOSED, CANCELLED = "진입 대기", "가상 보유", "가상 청산", "취소"
FROZEN = "세션 종료 · 평가 동결"
TICKER_INTERVAL = 15
TICKER_MAX_AGE = 90
LIVE_ASSETS = {"CRYPTO":("Upbit","Coinbase"),"KR":("FSC",),"US":("Alpha Vantage",)}
READY = {"목록 등재","일별 목록 등재","거래 가능"}
STOCK = {"주식","ETF"}


def enabled(cfg):
    return cfg["enabled"] and not cfg["paused"] and cfg["mode"]==MODE


def provider_ready(region):
    keys = {"KR":"KR_FSC_KEY","US":"ALPHA_VANTAGE_KEY"}
    return region=="CRYPTO" or bool(os.getenv(keys[region]))


def valid_asset(asset):
    if asset["state"] not in READY or asset["provider"] not in LIVE_ASSETS.get(asset["region"],()):
        return False
    if asset["region"]=="CRYPTO":
        return asset["kind"]=="현물"
    return asset["kind"] in STOCK and not re.search(
        r"(?i)leverag|inverse|[23]x\b|warrants?|rights?\b|레버리지|인버스|스팩",asset["name"])


def sample(store, region, provider, count):
    key="rotation-"+provider
    saved=store.get("auto_cursor",key) or {}
    last=saved.get("after","")
    # Generated JSON fields are read only for a small indexed region batch.
    def get(after, before="", limit=60):
        return store.query("""SELECT id,body FROM assets WHERE region=? AND id>? AND (?='' OR id<=?)
          AND json_extract(body,'$.provider')=? ORDER BY id LIMIT ?""",
          (region,after,before,before,provider,limit))
    page=get(last)
    if len(page)<60 and last:
        start=get("",last,60-len(page))
        page.extend(start)
    picked=[]
    final=last
    current={r["asset"] for r in store.query(
        "SELECT asset FROM auto_cycles WHERE state IN (?,?) AND region=?",(QUEUED,OPEN,region))}
    for row in page:
        final=row["id"]
        if row["id"] not in current and valid_asset(a:=json.loads(row["body"])):
            picked.append(a)
        if len(picked)==count:
            break
    store.put("auto_cursor",key,{"after":final})
    return picked


def frame_for(region):
    return "5m" if region=="CRYPTO" else "1d"


def universe_schedule_key(region, session_id):
    return f"automatic-universe-{region}-{session_id}"


def stamp(text):
    return datetime.fromisoformat(text).astimezone(UTC)


def valid_series(asset, series, observed):
    if not series["bars"] or series["source"]!=asset["provider"]:
        return False
    crypto=asset["region"]=="CRYPTO"
    if series["quality"]!=(HISTORY if crypto else DELAYED):
        return False
    bar=stamp(series["bars"][-1]["time"])
    check=stamp(observed)
    age=timedelta(minutes=20) if crypto else timedelta(days=5)
    return timedelta(0)<=check-bar<=age and bar<=stamp(series["retrieved"])<=check


def select_signal(scores, cfg):
    allowed=set(cfg["strategy_ids"])|{"chart","technical","volume","fundamental","macro","news","community"}
    active={key:val for key,val in scores.items() if val in (-1,1) and key in allowed}
    # At least one price/financial method must agree. A headline or crowd score cannot drive an entry.
    core={"chart","technical","volume","seykota","simons","marks","buffett","graham","lynch","oneil","fundamental"}
    long=[k for k,x in active.items() if x==1]
    short=[k for k,x in active.items() if x==-1]
    side,agree,disagree=("LONG",long,short) if len(long)>len(short) else ("SHORT",short,long)
    valid = len(agree)>=2 and len(agree)>len(disagree) and bool(core.intersection(agree))
    allow=cfg["long_research" if side=="LONG" else "short_research"]
    return side if valid and allow else None,agree,disagree


def _account(conn, obj, cfg):
    scope=obj["region"],obj["direction"],obj["currency"]
    if obj.get("session",sessions.LEGACY)!=sessions.LEGACY:
        return conn.execute("SELECT * FROM auto_session_accounts WHERE session=? AND region=? AND direction=? AND currency=?",
                            (obj["session"],*scope)).fetchone()
    initial=str(cfg["initial_"+obj["currency"].lower()])
    conn.execute("INSERT OR IGNORE INTO auto_accounts VALUES(?,?,?,?,?,?)",(*scope,initial,initial,"0"))
    return conn.execute("SELECT * FROM auto_accounts WHERE region=? AND direction=? AND currency=?",scope).fetchone()


def _update_wallet(conn, obj, cash, realized):
    if obj.get("session",sessions.LEGACY)!=sessions.LEGACY:
        conn.execute("""UPDATE auto_session_accounts SET cash=?,realized=?
            WHERE session=? AND region=? AND direction=? AND currency=?""",
            (str(cash),str(realized),obj["session"],obj["region"],obj["direction"],obj["currency"]))
        return
    conn.execute("UPDATE auto_accounts SET cash=?, realized=? WHERE region=? AND direction=? AND currency=?",
                 (str(cash),str(realized),obj["region"],obj["direction"],obj["currency"]))


def _update_cycle(conn, obj, state, at, **data):
    obj.update(state=state,updated=at,**data)
    conn.execute("UPDATE auto_cycles SET state=?,updated=?,body=? WHERE id=?",(state,at,encode(obj),obj["id"]))
    if state in (OPEN,CLOSED,CANCELLED,FROZEN):
        append(conn,"auto_simulation",{"id":obj["id"],"state":state,"hash":digest(obj)},at)
        detail = obj.get("entry_basis") if state==OPEN else obj.get("exit_basis")
        _timeline(conn,obj,state,at,detail or {"reason":obj.get("reason")})
    if state in (CLOSED,CANCELLED,FROZEN):
        amount=Decimal(obj["realized"]) if obj.get("realized") is not None else None
        exit_basis=obj.get("exit_basis") or {}
        accounting_result=("평가 동결" if state==FROZEN else "보류·취소" if amount is None else
                           "가상 이익" if amount>0 else "가상 손실" if amount<0 else "가상 손익 없음")
        Learning.append_in(conn,"automatic_outcome","result-"+obj["id"],obj["asset"],{
            "cycle":obj["id"],"session":obj.get("session",sessions.LEGACY),"snapshot":obj.get("snapshot"),
            "direction":obj["direction"],"state":state,
            "result":accounting_result,"accounting_result":accounting_result,
            "research_verdict":"미판정 · 독립 검증 없음",
            "exit_rule":exit_basis.get("rule"),"exit_snapshot":exit_basis.get("decision_snapshot"),
            "pnl":obj.get("realized"),"entry_bar":obj.get("entry_bar"),"exit_bar":obj.get("exit_bar"),
            "source_url":obj["source_url"],"reason":obj.get("reason"),
            "uncertainty":"가상체결 모델의 결과이며 연구 방법의 유효성을 검증하지 않습니다."},at)


def _timeline(conn,obj,stage,at,detail):
    token=digest([obj["id"],stage,detail])[:40]
    Learning.append_in(conn,"trade_lifecycle","trade-stage-"+token,obj["asset"],{
        "cycle":obj["id"],"session":obj.get("session",sessions.LEGACY),"snapshot":detail.get("decision_snapshot") or obj.get("snapshot"),
        "stage":stage,"at":at,"detail":detail,"execution_model":"python/auto-2",
        "llm_participation":"체결 판단에 사용하지 않음"},at)


def _basis(series, bar, observed, frame):
    closed=bar["time"]
    opened=(stamp(closed)-timedelta(minutes=5)).isoformat(timespec="seconds") if frame=="5m" else None
    return {"bar_open_at":opened,"bar_close_at":closed,"data_available_at":series["retrieved"],
            "collected_at":series["retrieved"],"decision_at":observed,"observed_price":str(bar["close"]),
            "volume":bar["volume"],"source":series["source"],"definition":"이 앱이 관측한 데이터 가용 시각"}


def _liquidation_value(obj, close):
    sign = 1 if obj["direction"]=="LONG" else -1
    fee = decimal(obj["fee_bps"])/10000
    move = (decimal(obj["slippage_bps"])+decimal(obj["spread_bps"])/2)/10000
    qty,entry,notional = (Decimal(obj[k]) for k in ("qty","entry","notional"))
    price = close*(1-sign*move)
    cost = qty*price*fee
    return price,cost,max(Decimal(0),notional+qty*(price-entry)*sign-cost)


def position_limits(initial, cash, fee, close, base_volume, *, capital_fraction=Decimal(".025")):
    return {"계정 초기금 비율 제한":initial*capital_fraction,
            "수수료 포함 가용 현금":cash/(1+fee),
            "완료 봉 거래대금의 0.1% 추정":base_volume*close/1000}


def _open_cycle(conn,obj,bar,observed,cfg,basis):
    if not cfg["long_research" if obj["direction"]=="LONG" else "short_research"]:
        _update_cycle(conn,obj,CANCELLED,observed,reason="방향 연구 끄기")
        return
    book=_account(conn,obj,cfg)
    if not book:
        _update_cycle(conn,obj,CANCELLED,observed,reason="이 세션의 시장·방향·통화 가상 계정이 없습니다.")
        return
    cash=Decimal(book["cash"])
    fee=decimal(obj["fee_bps"])/10000
    move=(decimal(obj["slippage_bps"])+decimal(obj["spread_bps"])/2)/10000
    close=decimal(bar["close"],"0.000000000001")
    sign=1 if obj["direction"]=="LONG" else -1
    execution=close*(1+sign*move)
    volume=decimal(bar["volume"] or 0)
    limits=position_limits(Decimal(book["initial"]),cash,fee,close,volume)
    reason=min(limits,key=limits.get)
    notional=limits[reason]
    session=conn.execute("SELECT currency_krw,currency_usd FROM auto_sessions WHERE id=?",(obj.get("session"),)).fetchone()
    total=Decimal(session["currency_"+obj["currency"].lower()]) if session else None
    sizing={"limit":reason,"limits":{k:str(v) for k,v in limits.items()},"notional":str(notional),
            "initial_account":book["initial"],"cash_before":str(cash),
            "session_initial_pct":str(notional*100/total) if total else None,
            "policy":"sizing-v1","capital_fraction":"0.025","liquidity_fraction":"0.001",
            "market":obj["region"],"venue":obj["source"],"currency":obj["currency"],
            "allocation_direction":obj["direction"],"reference_close":str(close),"base_volume":str(volume),
            "volume_unit":"기초 자산 수량" if obj["region"]=="CRYPTO" else "주 수",
            "estimated_quote_turnover":str(volume*close),"published_quote_turnover":bar.get("turnover"),
            "bar_close_at":bar["time"],"received_at":basis["collected_at"],"fee_bps":obj["fee_bps"],
            "minimum_notional":"100" if obj["currency"]=="KRW" else "1",
            "reserved_cash":"0","reservation_rule":"진입 대기는 예약하지 않음 · 체결 시 트랜잭션 내 가용 현금 확인"}
    if notional<Decimal(100 if obj["currency"]=="KRW" else 1):
        _update_cycle(conn,obj,CANCELLED,observed,reason="가상 잔액 또는 관측 거래량 부족",sizing=sizing)
        return
    entry_fee=notional*fee
    _update_wallet(conn,obj,cash-notional-entry_fee,Decimal(book["realized"]))
    qty=notional/execution
    fields={"entry_bar":bar["time"],"entry_observed":observed,"entry":str(execution),"notional":str(notional),
            "qty":str(qty),"entry_fee":str(entry_fee),"mark":str(close),"mark_bar":bar["time"],
            "sizing":sizing | {"cash_after":str(cash-notional-entry_fee)},
            "entry_basis":basis | {"simulated_fill_at":observed,"rule":"entry.new_closed_bar"}}
    fields["mark_equity"]=str(_liquidation_value(obj | fields,close)[2])
    _update_cycle(conn,obj,OPEN,observed,**fields)


def _mark_cycle(conn,obj,bars,observed,side,cfg,basis,agree,disagree):
    bar=bars[-1]
    close=decimal(bar["close"],"0.000000000001")
    sign=1 if obj["direction"]=="LONG" else -1
    entry,notional,past_fee=(Decimal(obj[k]) for k in ("entry","notional","entry_fee"))
    exit_price,exit_fee,released=_liquidation_value(obj,close)
    closed_count=sum(b["time"]>obj["entry_bar"] for b in bars)
    move_ratio=sign*(close/entry-1)
    horizon=FIXED_EXIT_BARS[obj["region"]]
    rule,reason=decide_exit(obj["direction"],side,released,move_ratio,closed_count,horizon)
    detail=basis | {"rule":rule,"reason":reason,"direction":side,"agree":agree,"disagree":disagree,
                    "elapsed_bars":closed_count,"horizon_bars":horizon,"move_ratio":str(move_ratio),
                    "policy_version":POLICY_VERSION}
    marks={"mark":str(close),"mark_bar":bar["time"],"mark_equity":str(released)}
    if rule=="hold.no_exit" or not bar["volume"]:
        # A zero-volume bar may update an observed mark but cannot close a position.
        obj.update(updated=observed,**marks)
        conn.execute("UPDATE auto_cycles SET updated=?,body=? WHERE id=?",(observed,encode(obj),obj["id"]))
        _timeline(conn,obj,"보유 재검토",observed,detail | {"liquidity_block":not bool(bar["volume"])})
        interval=INTERIM_INTERVAL_BARS[obj["region"]]
        checkpoint=closed_count//interval
        if checkpoint:
            ident="auto-interim-"+digest([obj["id"],checkpoint,interval])[:40]
            Learning.append_in(conn,"automatic_interim_evaluation",ident,obj["asset"],{
                "cycle":obj["id"],"session":obj.get("session",sessions.LEGACY),
                "direction":obj["direction"],"currency":obj["currency"],
                "snapshot":detail["decision_snapshot"],"checkpoint":checkpoint,"interval_bars":interval,
                "mark_pnl":str(released-notional-past_fee),"liquidity_block":not bool(bar["volume"]),
                "research_verdict":"미판정 · 보유 중 관측","basis":detail},observed)
        return OPEN
    book=_account(conn,obj,cfg)
    pnl=released-notional-past_fee
    _update_wallet(conn,obj,Decimal(book["cash"])+released,Decimal(book["realized"])+pnl)
    _update_cycle(conn,obj,CLOSED,observed,**marks,exit=str(exit_price),exit_bar=bar["time"],exit_observed=observed,
                  reason=reason,exit_fee=str(exit_fee),realized=str(pnl),
                  exit_basis=detail | {"simulated_fill_at":observed},
                  cash_after_exit=str(Decimal(book["cash"])+released))
    return CLOSED


def _decision_snapshot(conn, obj, series, scores, basis, research, at):
    ident="auto-decision-"+digest([obj["id"],basis["bar_close_at"],obj["state"]])[:40]
    Learning.append_in(conn,"automatic_snapshot",ident,obj["asset"],{
        "bars":series["bars"][-60:],"frame":obj["frame"],"scores":scores,"source_url":series["url"],
        "collected_at":series["retrieved"],"version":"auto-2","research":research or {},
        "session":obj.get("session"),"decision_basis":basis},at)
    return basis | {"decision_snapshot":ident}


WAIT_REASONS = {
    "expired":"후속 관측 대기 만료",
    "missing_series":"체결 판단에 사용할 완료 봉을 아직 확보하지 못했습니다.",
    "inactive_asset":"종목의 거래 가능 상태를 확인할 때까지 보류합니다.",
    "invalid_series":"저장된 봉의 출처, 최신성 또는 수신 시각을 검증하지 못했습니다.",
    "before_signal":"신호 등록 이후에 마감된 완료 봉을 기다립니다.",
    "no_volume":"완료 봉의 거래량이 없어 가상 체결을 보류합니다.",
    "price_gap":"급격한 가격 변화 · 조정·자료 확인 필요",
    "paused":"자동 모의투자가 일시정지되어 있습니다.",
    "eligible":"후속 완료 봉 확인 · 가상 금액·체결 조건 판정 대기",
}


def _pending_gate(trade, asset, series, observed):
    expires=timedelta(hours=4) if trade["region"]=="CRYPTO" else timedelta(days=7)
    signal=stamp(trade["signal_seen"])
    if stamp(observed)-signal>expires:
        return "expired"
    if asset is None or not valid_asset(asset):
        return "inactive_asset"
    if not series or not series.get("bars"):
        return "missing_series"
    if not valid_series(asset,series,observed):
        return "invalid_series"
    bar=series["bars"][-1]
    if stamp(bar["time"])<=signal:
        return "before_signal"
    if not bar["volume"]:
        return "no_volume"
    if abs(decimal(bar["close"],"0.000000000001")/Decimal(trade["signal_price"])-1)>Decimal(".30"):
        return "price_gap"
    return "eligible"


def _entry_view(trade, asset, series, last_check, paused=False):
    is_crypto=trade["region"]=="CRYPTO"
    pending=trade["state"]==QUEUED
    check=("paused" if paused else _pending_gate(trade,asset,series,now())) if pending else None
    recent=series["bars"][-1] if series and series.get("bars") else None
    delay=("공개 완료 5분봉 · 장중 지정가 감시 없음" if is_crypto else "지연 일봉 · 장중 현재가 미확보")
    return {"order_type":"신호 이후 완료 5분봉 종가 기준" if is_crypto else "신호 이후 완료 일봉 종가 기준",
            "reference_price":trade.get("signal_price"),"reference_at":trade.get("signal_bar"),
            "reference_source":trade.get("source"),"queued_price":None,
            "reference_observed_at":trade.get("signal_seen"),"wait_reason":WAIT_REASONS.get(check),"wait_code":check,
            "data_delay":delay,"last_scan_at":last_check.get("checked"),"last_scan_status":last_check.get("state"),
            "latest":{"price":recent["close"],"at":recent["time"],"received_at":series.get("retrieved"),
                      "quality":series.get("quality"),"source":series.get("source")} if recent else None}


def process(store, asset, series, scores, observed=None, admit=True, research=None, expected_session=None):
    observed=observed or now()
    if not valid_asset(asset) or not valid_series(asset,series,observed):
        return None
    bars=series["bars"]
    bar=bars[-1]
    with store.tx() as conn:
        cfg=store.settings(conn)
        if not enabled(cfg) or asset["region"] not in cfg["markets"]:
            return None
        session=sessions.active(conn)
        ident_session=session["id"] if session else sessions.LEGACY
        if (expected_session is not None and ident_session!=expected_session) or (session and session["state"]!="running"):
            return None
        if session:
            basis=json.loads(session["body"])
            if asset["region"] not in basis["markets"]:
                return None
            cfg=cfg | {k:basis[k] for k in ("fee_bps","slippage_bps","spread_bps","strategy_ids")}
        side,agree,disagree=select_signal(scores,cfg)
        basis=_basis(series,bar,observed,frame_for(asset["region"]))
        active=conn.execute("SELECT body FROM auto_cycles WHERE session=? AND asset=? AND state IN (?,?)",
                            (ident_session,asset["id"],QUEUED,OPEN)).fetchone()
        if active:
            row=json.loads(active["body"])
            if row["state"]==QUEUED:
                gate=_pending_gate(row,asset,series,observed)
                if gate in ("expired","price_gap"):
                    _update_cycle(conn,row,CANCELLED,observed,reason=WAIT_REASONS[gate])
                    return CANCELLED
                if gate=="eligible":
                    decision=_decision_snapshot(conn,row,series,scores,basis,research,observed)
                    _open_cycle(conn,row,bar,observed,cfg,decision)
                    return row["state"]
            elif stamp(bar["time"])>stamp(row["mark_bar"]):
                decision=_decision_snapshot(conn,row,series,scores,basis,research,observed)
                return _mark_cycle(conn,row,bars,observed,side,cfg,decision,agree,disagree)
            return row["state"]
        if not admit or len(bars)<50 or not side or not bar["volume"]:
            return None
        cycle_key=[asset["id"],bar["time"],side]
        if ident_session!=sessions.LEGACY:
            cycle_key.insert(0,ident_session)
        ident="auto-direction-"+digest(cycle_key)[:36]
        snapshot_id="auto-snapshot-"+ident
        obj={"id":ident,"session":ident_session,"asset":asset["id"],"region":asset["region"],
             "direction":side,"currency":asset["currency"],
             "state":QUEUED,"created":observed,"updated":observed,"signal_seen":observed,"signal_bar":bar["time"],
             "source":series["source"],"source_url":series["url"],"quality":series["quality"],"agree":agree,
             "signal_price":str(bar["close"]),"execution_type":"post_signal_completed_bar","snapshot":snapshot_id,"disagree":disagree,"frame":frame_for(asset["region"]),
             "signal_basis":basis | {"rule":"entry.signal_consensus","agree":agree,"disagree":disagree},
             **{k:cfg[k] for k in ("fee_bps","slippage_bps","spread_bps")}}
        inserted=conn.execute("INSERT OR IGNORE INTO auto_cycles VALUES(?,?,?,?,?,?,?)",
                              (ident,asset["id"],asset["region"],QUEUED,observed,encode(obj),ident_session)).rowcount
        if inserted:
            Learning.append_in(conn,"automatic_snapshot",snapshot_id,asset["id"],{
                "frame":obj["frame"],"bars":bars[-60:],"scores":scores,"source_url":series["url"],
                "collected_at":series["retrieved"],"direction":side,"version":"auto-2","session":ident_session,
                "agree":agree,"disagree":disagree,"research":research or {}},observed)
            append(conn,"auto_simulation",{"id":ident,"state":QUEUED,"hash":digest(obj)},observed)
            _timeline(conn,obj,QUEUED,observed,obj["signal_basis"])
            return QUEUED
    return None


class TradeNotFound(LookupError):
    pass


def detail(store, ident, *, live_marks=False):
    if not isinstance(ident,str) or not 1<=len(ident)<=100 or not ident.isascii() or not all(
            c.isalnum() or c in "-_" for c in ident):
        raise ValueError("가상 거래 ID 형식을 확인하세요.")
    learning=Learning(store)
    with closing(store.connect()) as conn:
        conn.execute("BEGIN")
        row=conn.execute("SELECT body FROM auto_cycles WHERE id=?",(ident,)).fetchone()
        if not row:
            raise TradeNotFound(ident)
        trade=json.loads(row["body"])
        def event(key):
            saved=conn.execute("SELECT * FROM learning_events WHERE id=?",(key,)).fetchone() if key else None
            return learning.decode(dict(saved)) if saved else None
        snapshot=event(trade.get("snapshot"))
        decisions=[learning.decode(dict(r)) for r in conn.execute("""SELECT * FROM learning_events
            WHERE kind IN ('trade_lifecycle','automatic_interim_evaluation') AND json_extract(data,'$.cycle')=?
            ORDER BY time,rowid""",(ident,))]
        timeline=[r for r in decisions if r["kind"]=="trade_lifecycle"]
        interim=[r for r in decisions if r["kind"]=="automatic_interim_evaluation"]
        outcome=event("result-"+ident)
        validations=[learning.decode(dict(r)) for r in conn.execute("""SELECT * FROM learning_events
            WHERE kind IN ('review_verdict','hypothesis_result','automatic_verification')
            AND (json_extract(data,'$.cycle')=? OR json_extract(data,'$.target')=?)
            ORDER BY time,rowid""",(ident,"result-"+ident))]
    ticker=store.get("auto_ticker",trade["asset"]) if live_marks else None
    valuation=None
    if trade["state"] in (OPEN,FROZEN) and all(trade.get(k) is not None for k in (
            "mark","mark_bar","entry","notional","qty","entry_fee","mark_equity")):
        valuation=_holding_view(trade,ticker,datetime.now(UTC))
    asset=store.search_exact(trade["asset"])
    latest=store.series(trade["asset"],frame_for(trade["region"]))
    check=store.get("source","automatic_scan "+trade["asset"]) or {}
    entry_view=_entry_view(trade,asset,latest,check,paused=not enabled(store.settings()))
    return {"trade":trade,"entry_plan":entry_view,"instrument":{k:asset.get(k) for k in ("name","venue") if asset and k in asset},
            "snapshot":snapshot,"timeline":timeline,"interim":interim,"exit_policy":policy_view(trade["region"]),
            "outcome":outcome,"validations":validations,"valuation":valuation}


def finalize_in(conn, session_id, at):
    for row in conn.execute("SELECT body FROM auto_cycles WHERE session=? AND state IN (?,?)",
                            (session_id,QUEUED,OPEN)).fetchall():
        obj=json.loads(row["body"])
        _update_cycle(conn,obj,CANCELLED if obj["state"]==QUEUED else FROZEN,at,
                      reason="가상 세션 종료 · 마지막 관측 가격 보존")
    conn.execute("""DELETE FROM records WHERE kind='auto_candidate'
        AND COALESCE(json_extract(body,'$.session'),'legacy')=?""",(session_id,))


def cancel_pending(store):
    with store.tx() as conn:
        cfg = store.settings(conn)
        if cfg["enabled"] and cfg["mode"]==MODE:
            return
        for row in conn.execute("SELECT body FROM auto_cycles WHERE state=?",(QUEUED,)).fetchall():
            _update_cycle(conn,json.loads(row["body"]),CANCELLED,now(),reason="자동 모의매매 정지")


def expire_pending(store):
    at=now()
    with store.tx() as conn:
        for row in conn.execute("SELECT body FROM auto_cycles WHERE state=?",(QUEUED,)).fetchall():
            obj=json.loads(row["body"])
            limit=timedelta(hours=4) if obj["region"]=="CRYPTO" else timedelta(days=7)
            if stamp(at)-stamp(obj["signal_seen"])>limit:
                _update_cycle(conn,obj,CANCELLED,at,reason="후속 관측 대기 만료")


def candidate(store, asset, series, scores, volume_ratio, research, expected_session=None):
    latest=series["bars"][-1]
    valid=valid_series(asset,series,now()) and len(series["bars"])>=50 and bool(latest["volume"])
    session_id=expected_session or sessions.active_id(store)
    with store.tx() as conn:
        settings=store.settings(conn)
        owner=sessions.active(conn)
        if (session_id!=(owner["id"] if owner else sessions.LEGACY) or not enabled(settings)
                or owner and owner["state"]!="running" or asset["region"] not in settings["markets"]):
            return
        if owner:
            settings["strategy_ids"]=json.loads(owner["body"])["strategy_ids"]
        side,agree,disagree=select_signal(scores,settings)
        state="INVALID" if not valid else side if side else "WAIT" if agree or disagree else "NEUTRAL"
        observation={"region":asset["region"],"asset":asset["id"],"state":state,"source":series["source"],
                     "session":session_id,"market_at":latest["time"],"retrieved_at":series["retrieved"],
                     "source_url":series["url"],"usable_methods":sum(v is not None for v in scores.values()),
                     "agree":agree,"disagree":disagree}
        at=now()
        conn.execute("INSERT OR REPLACE INTO records VALUES('auto_observation',?,?,?)",(asset["id"],at,encode(observation)))
        # Group repeated non-executions into one observation per session, day and disposition.
        if state in ("INVALID","NEUTRAL","WAIT"):
            ident="auto-observed-"+digest([session_id,asset["id"],at[:10],state])[:38]
            Learning.append_in(conn,"automatic_observation",ident,asset["id"],observation | {"research":research},at)
        if not valid or not side:
            conn.execute("DELETE FROM records WHERE kind='auto_candidate' AND id=?",(asset["id"],))
            return
        value={"asset":asset["id"],"region":asset["region"],"direction":side,"seen":at,"session":session_id,
               "bar":latest["time"],"scores":scores,"agree":agree,"disagree":disagree,"research":research,
               "priority":[len(agree)-len(disagree),len(agree),min(volume_ratio or 0,10)]}
        conn.execute("INSERT OR REPLACE INTO records VALUES('auto_candidate',?,?,?)",(asset["id"],at,encode(value)))


def select_candidate(store, region, expected_session=None):
    cfg=store.settings()
    if not enabled(cfg) or region not in cfg["markets"] or not provider_ready(region):
        return None
    session_id=expected_session or sessions.active_id(store)
    limit=timedelta(minutes=20) if region=="CRYPTO" else timedelta(days=4)
    rows=store.query("""SELECT body FROM records WHERE kind='auto_candidate' AND
        json_extract(body,'$.region')=? AND COALESCE(json_extract(body,'$.session'),'legacy')=? AND NOT EXISTS (
            SELECT 1 FROM auto_cycles c WHERE c.asset=records.id AND c.state IN (?,?)
        ) ORDER BY updated DESC LIMIT 120""",(region,session_id,QUEUED,OPEN))
    recent=[json.loads(row["body"]) for row in rows]
    recent=[row for row in recent if datetime.now(UTC)-stamp(row["seen"])<=limit]
    for item in sorted(recent,key=lambda row:(row["priority"],row["seen"]),reverse=True):
        asset=store.asset(item["asset"])
        series=store.series(asset["id"],frame_for(region))
        if not series or series["bars"][-1]["time"]!=item["bar"]:
            continue
        state=process(store,asset,series,item["scores"],research=item["research"],expected_session=session_id)
        if state==QUEUED:
            store.write("""DELETE FROM records WHERE kind='auto_candidate' AND id=?
                        AND COALESCE(json_extract(body,'$.session'),'legacy')=?""",(asset["id"],session_id))
            return asset["id"]
    return None


def coverage(store):
    sizes={}
    for region,catalogs in {"KR":("KR","KR-ETF"),"US":("NASDAQ","NYSE"),"CRYPTO":("Upbit","Coinbase")}.items():
        known=set().union(*[(store.get("catalog",catalog) or {}).get("ids",[]) for catalog in catalogs])
        records=store.query("""SELECT id FROM records WHERE kind='auto_observation'
           AND json_extract(body,'$.region')=?""",(region,))
        observed={row["id"] for row in records}
        failed={row["id"].split(" ",1)[1] for row in store.query("""SELECT id FROM records WHERE kind='source'
            AND id LIKE ? AND json_extract(body,'$.state')='수집 실패'""",("automatic_scan "+region+":%",))}
        excluded={r["id"] for r in store.query("""SELECT id FROM assets WHERE region=? AND
                    (json_extract(body,'$.state') LIKE '목록 제외%' OR json_extract(body,'$.kind')='지수')""",(region,))}
        unsupported=known & excluded
        sizes[region]={"listed":len(known),"observed":len(observed),"unobserved":len(known-observed),
                       "failed":len(failed),"failed_unobserved":len((known-observed)&failed),"unsupported":len(unsupported),
                       "not_yet":len(known-observed-failed-unsupported)}
    return sizes


def _holding_view(obj, ticker, clock):
    current = {k:obj.get(k) for k in ("id","asset","direction","currency","state","entry","mark","mark_bar","qty",
                                     "mark_equity","entry_observed","notional","entry_fee")}
    current["mark_source"] = ("동결 · 완료 봉" if obj["state"]==FROZEN else
                              "5분 완료 봉" if obj["region"]=="CRYPTO" else "지연 일봉")
    if obj["state"]==OPEN and obj["region"]=="CRYPTO" and ticker:
        trade,receipt = stamp(ticker["time"]),stamp(ticker["retrieved"])
        if ticker["asset"]==obj["asset"] and ticker["source"]==obj["source"] and trade<=receipt<=clock:
            current["ticker_checked"]=ticker["retrieved"]
        if (ticker["asset"]==obj["asset"] and ticker["source"]==obj["source"]
                and max(stamp(obj["mark_bar"]),stamp(obj["entry_observed"]))<=trade<=receipt<=clock
                and (clock-trade).total_seconds()<=TICKER_MAX_AGE):
            price = decimal(ticker["price"],"0.000000000001")
            current.update(mark=str(price),mark_bar=ticker["time"],mark_equity=str(_liquidation_value(obj,price)[2]),
                           mark_source="공개 최근 체결가")
    basis=Decimal(current["notional"])+Decimal(current["entry_fee"])
    pnl=Decimal(current["mark_equity"])-basis
    age=(clock-stamp(current["mark_bar"])).total_seconds()
    return current | {"region":obj["region"],"pnl":str(pnl),"return_pct":str(pnl*100/basis) if basis else None,
                      "stale":age>(1200 if obj["region"]=="CRYPTO" else 86400*5)}


def _valid_fx(point, clock):
    try:
        age=(clock.date()-datetime.fromisoformat(point["date"]).date()).days
        rate=Decimal(str(point["value"]))
        return 0<=age<=7 and rate.is_finite() and rate>0
    except (ArithmeticError,KeyError,TypeError,ValueError):
        return False


def report(store, offline, *, include_trades=True, live_marks=False):
    cfg=store.settings()
    region_state={}
    sizes=coverage(store)
    for region in LIVE_ASSETS:
        count=sizes[region]["listed"]
        progress=store.get("auto_status",region) or {}
        state=("오프라인" if offline else "제공처 키 미설정" if not provider_ready(region) else
               "시장 사용 안 함" if region not in cfg["markets"] else
               "무료 요청 한도 대기" if progress.get("quota_limited") else
               "목록 갱신 대기" if not count else "순회 가능")
        region_state[region]=sizes[region]|{"state":state,"frame":frame_for(region),"checked":progress.get("last_checked"),
                             "last_asset":progress.get("last_asset"),"available_methods":progress.get("available_methods")}
    with closing(store.connect()) as conn:
        conn.execute("BEGIN")
        active=sessions.active(conn)
        selected=active or conn.execute("SELECT * FROM auto_sessions ORDER BY created DESC,rowid DESC LIMIT 1").fetchone()
        session=sessions.details(conn,selected) if selected else None
        selected_id=session["id"] if session else sessions.LEGACY
        if session:
            accounts=[dict(row) for row in conn.execute("""SELECT * FROM auto_session_accounts WHERE session=?
                ORDER BY region,direction,currency""",(session["id"],))]
            session["completed"]=conn.execute("SELECT COUNT(*) FROM auto_cycles WHERE session=? AND state=?",
                                              (session["id"],CLOSED)).fetchone()[0]
        else:
            accounts=[dict(row) for row in conn.execute("SELECT * FROM auto_accounts ORDER BY region,direction,currency")]
        open_rows = conn.execute("""SELECT c.body, r.body ticker FROM auto_cycles c
            LEFT JOIN records r ON r.kind='auto_ticker' AND r.id=c.asset AND ? AND c.state=?
            WHERE c.session=? AND c.state IN (?,?) ORDER BY c.asset""",
            (live_marks and not offline and enabled(cfg),OPEN,selected_id,OPEN,FROZEN)).fetchall()
        pending = [json.loads(row["body"]) for row in conn.execute(
            "SELECT body FROM auto_cycles WHERE session=? AND state=? ORDER BY updated DESC",(selected_id,QUEUED))]
        recent_closed = [json.loads(row["body"]) for row in conn.execute(
            "SELECT body FROM auto_cycles WHERE session=? AND state=? ORDER BY updated DESC,id DESC LIMIT 5",(selected_id,CLOSED))]
        fee_rows=conn.execute("""SELECT json_extract(body,'$.currency') currency,
            json_extract(body,'$.entry_fee') entry_fee,json_extract(body,'$.exit_fee') exit_fee
            FROM auto_cycles WHERE session=? AND state IN (?,?,?)""",(selected_id,OPEN,CLOSED,FROZEN)).fetchall()
        fx_row=conn.execute("SELECT body FROM records WHERE kind='macro' AND id='DEXKOUS'").fetchone()
        equity_scope=selected_id+":*"
        history_rows=conn.execute("""SELECT id,body FROM records WHERE kind='equity_history'
            AND id GLOB ? ORDER BY id DESC LIMIT 168""",(equity_scope,)).fetchall()
        older_rows=conn.execute("""SELECT body FROM records WHERE kind='equity_history' AND id IN (
            SELECT MAX(id) FROM records WHERE kind='equity_history' AND id GLOB ? AND id<?
            GROUP BY substr(id,length(?)+2,10) ORDER BY MAX(id) DESC LIMIT 366)
            ORDER BY id DESC""",(equity_scope,history_rows[-1]["id"],selected_id)).fetchall() if len(history_rows)==168 else []
        trades=[json.loads(row["body"]) for row in conn.execute(
            "SELECT body FROM auto_cycles ORDER BY updated DESC LIMIT 120")] if include_trades else []
        history=[dict(row) for row in conn.execute(
            "SELECT id,created,started,ended,state FROM auto_sessions ORDER BY created DESC,rowid DESC LIMIT 12")]
    marked={}
    holdings=[]
    clock=datetime.now(UTC)
    for row in open_rows:
        obj=json.loads(row["body"])
        view=_holding_view(obj,json.loads(row["ticker"]) if row["ticker"] else None,clock)
        scope=tuple(obj[k] for k in ("region","direction","currency"))
        marked[scope]=marked.get(scope,Decimal(0))+Decimal(view["mark_equity"])
        holdings.append(view)
    for account in accounts:
        scope=tuple(account[k] for k in ("region","direction","currency"))
        equity=Decimal(account["cash"])+marked.get(scope,Decimal(0))
        account["equity"]=str(equity)
        account["unrealized"]=str(equity-sum(Decimal(account.get(k,"0")) for k in ("initial","added","realized")))
    totals={}
    allocation=[]
    if session:
        for currency in ("KRW","USD"):
            rows=[a for a in accounts if a["currency"]==currency]
            initial=Decimal(session["currency_"+currency.lower()])
            total={k:sum((Decimal(a[k]) for a in rows),Decimal(0)) for k in ("equity","added","realized","unrealized")}
            total["equity"]+=initial-sum(Decimal(a["initial"]) for a in rows)
            total["initial"]=initial
            total["pnl"]=total["realized"]+total["unrealized"]
            total["positions"]=sum((Decimal(h["mark_equity"]) for h in holdings if h["currency"]==currency),Decimal(0))
            total["cash"]=total["equity"]-total["positions"]
            total["reserved"]=Decimal(0)
            total["available"]=sum((Decimal(a["cash"]) for a in rows),Decimal(0))
            total["exposure"]=sum((Decimal(h["qty"])*Decimal(h["mark"]) for h in holdings
                                   if h["currency"]==currency and h["state"]==OPEN),Decimal(0))
            total["fees"]=sum((Decimal(row["entry_fee"] or "0")+Decimal(row["exit_fee"] or "0")
                               for row in fee_rows if row["currency"]==currency),Decimal(0))
            basis=total["initial"]+total["added"]
            total["return_pct"]=total["pnl"]*100/basis if basis else Decimal(0)
            total["capital_in_use"]=sum((Decimal(h["notional"]) for h in holdings if h["currency"]==currency),Decimal(0))
            total["used_pct"]=total["capital_in_use"]*100/basis if basis else Decimal(0)
            totals[currency]={k:str(v) for k,v in total.items()}
            for region in LIVE_ASSETS:
                rr=[a for a in rows if a["region"]==region]
                held=sum((Decimal(h["mark_equity"]) for h in holdings
                          if h["region"]==region and h["currency"]==currency),Decimal(0))
                if rr:
                    allocation.append({"region":region,"currency":currency,"positions":str(held),
                        **{k:str(sum(Decimal(a[k]) for a in rr)) for k in ("cash","initial","added","equity","realized")}})
    fx=json.loads(fx_row[0]) if fx_row else None
    point=fx["points"][-1] if fx and fx.get("points") else None
    if point and fx.get("source")=="FRED" and _valid_fx(point,clock):
        fx={"rate":point["value"],"date":point["date"],"collected_at":fx.get("retrieved"),"source":"FRED",
            "stale":(clock.date()-datetime.fromisoformat(point["date"]).date()).days>7,
            "equity_krw":str(Decimal(totals["KRW"]["equity"])+Decimal(totals["USD"]["equity"])*Decimal(str(point["value"])))
            if totals else None}
    else:
        fx=None
    equity_history=[json.loads(row["body"]) for row in reversed(history_rows+older_rows)]
    korea=timezone(timedelta(hours=9))
    day=clock.astimezone(korea).date()
    for currency,total in totals.items():
        first=next((item for item in equity_history if stamp(item["at"]).astimezone(korea).date()==day
                    and currency in item["totals"]),None)
        total["daily_pnl"]=str(Decimal(total["pnl"])-Decimal(first["totals"][currency]["pnl"])) if first else None
        total["daily_equity"]=str(Decimal(total["equity"])-Decimal(first["totals"][currency]["equity"])) if first else None
    return {"running":enabled(cfg) and not offline and not cfg["research_paused"] and cfg["resource_mode"]!="eco",
            "regions":region_state,"accounts":accounts,"trades":trades,
            "session":session,"sessions":history,"totals":totals,"holdings":holdings,"pending":pending,
            "recent_closed":recent_closed,
            "allocation":allocation,"fx":fx,"equity_history":equity_history,
            "heartbeat":store.get("auto_runtime","heartbeat"),
            "note":"거래소 관측 시점 후 수신된 완료 봉의 종가에 가상 비용을 적용합니다. 가상 원장별 자산과 통화를 합산하지 않습니다."}


def sample_equity(store, offline):
    view=report(store,offline,include_trades=False)
    if view["session"] and view["session"]["state"]=="running":
        at=now()
        key=view["session"]["id"]+":"+at[:16]
        store.put("equity_history",key,{"at":at,"session":view["session"]["id"],"totals":view["totals"]})
        for region,counts in view["regions"].items():
            store.put("coverage_history",key+":"+region,{"at":at,"region":region,**counts})
