from dataclasses import asdict, dataclass
import statistics as stats

from indicators.technical import avg, pct


@dataclass(frozen=True)
class Strategy:
    id: str
    title: str
    method: str
    market: str
    inputs: str
    suitable: str
    limit: str
    url: str
    version: str = "1.0.0"

    def json(self):
        return asdict(self)


MODELS = [
    Strategy("buffett","워런 버핏","현금흐름·수익성","주식","ROE, 잉여현금흐름, 이익수익률","안정적인 사업","내재가치와 경쟁우위 전체가 포함되지 않습니다.","https://www.berkshirehathaway.com/2001ar/ownersmanual.html"),
    Strategy("graham","벤저민 그레이엄","안전마진·재무 건전성","주식","PER, PBR, 부채비율","가치·재무 관찰","청산가치·산업별 적정 배수는 빠집니다.","https://www.harpercollins.com/products/the-intelligent-investor-rev-ed-benjamin-graham"),
    Strategy("lynch","피터 린치","성장 대비 가치","주식","매출 성장, PER, 영업이익률","성장과 이익을 함께 관찰","산업별 특성과 정성 정보는 수동 확인이 필요합니다.","https://www.simonandschuster.com/books/One-Up-On-Wall-Street/Peter-Lynch/9780743200400"),
    Strategy("dalio","레이 달리오","시장 환경·거시 연구","공통","추세, 변동성, 장단기 금리 관측","거시 데이터가 충분한 구간","위험평가 단순화. 다자산 위험균형 미지원.","https://www.principles.com/"),
    Strategy("soros","조지 소로스","가격·기대 동행 연구","공통","추세, 가격 가속도, 거래량, 여론","가격과 여론 자료가 겹치는 구간","상관을 인과관계나 재귀성으로 해석할 수 없습니다.","https://www.georgesoros.com/2008/11/06/the_crisis_what_to_do_about_it/"),
    Strategy("marks","하워드 막스","사이클·위험 연구","공통","변동성, RSI, 낙폭","경기 및 심리 극단 관찰","신용 사이클과 가치 평가는 빠집니다.","https://www.oaktreecapital.com/docs/default-source/memos/2001-11-20-you-cant-predict-you-can-prepare.pdf"),
    Strategy("simons","짐 사이먼스 참고","평균회귀 가설","공통","20봉 표준점수, 변동성","횡보 구간","공개 통계 개념을 사용한 독립 실험입니다.","https://www.simonsfoundation.org/2024/05/10/jim-simons-1938-2024/"),
    Strategy("seykota","에드 세이코타","장단기 추세 비교","공통","20/50봉 이동평균","중기 추세가 유지되는 구간","횡보장에서 빈번한 반전이 가능합니다.","https://www.seykota.com/tribe/FAQ/index.htm"),
    Strategy("oneil","윌리엄 오닐","성장·돌파 연구","주식","매출 성장, 이전 20봉 돌파, 거래량","성장과 수급이 겹치는 구간","CAN SLIM의 일부 요소를 단순화했습니다.","https://get.investors.com/wp-content/uploads/2025/01/How-To-Use-SwingTrader-2025.pdf"),
    Strategy("chart","차트 패턴","이전 고저점 돌파","공통","이전 20봉 고가·저가","방향성이 생기는 구간","가격 구조를 단순화합니다.",""),
    Strategy("volume","거래량","거래량과 가격 변화","공통","20봉 상대 거래량, 직전 종가","평소 대비 거래량 급증","거래량 증가의 원인은 별도 확인이 필요합니다.",""),
    Strategy("news","뉴스","공식 본문 언어 지표","공통","종목과 연결된 최근 공식 본문","공식 발표 직후","사전 기반 감성은 맥락에 약합니다.",""),
    Strategy("community","커뮤니티","언급과 감성 관찰","공통","공개 댓글 본문, 언급량","관련 댓글 표본이 충분한 구간","표본 선택·루머·광고 가능성이 있습니다.",""),
    Strategy("macro","거시경제","미국 금리차 관측","공통","연방기금금리, 미국 10년물","금리 수치가 제공되는 구간","현재 판본과 관측일 기준의 단순 비교입니다.",""),
    Strategy("fundamental","기업 가치","재무 체력 비교","주식","ROE, 부채비율, 영업이익률","비교 가능한 회사 재무","현재 공시만 수집하며, 과거 발표 시점 데이터는 별도입니다.",""),
    Strategy("technical","기술적 지표","MACD·RSI 결합","공통","MACD 히스토그램, RSI","추세 전환 관찰","수치 범위의 경험적 가설입니다.",""),
    Strategy("combined","복합 분석","독립 신호의 합의","공통","차트, 거래량, 기술, 뉴스, 재무, 거시, 여론","세 가지 이상 자료가 확인되는 구간","같은 가격 데이터에서 얻은 신호는 독립 표본이 아닙니다.",""),
]
BY_ID = {item.id:item for item in MODELS}
HISTORICAL = ("marks","simons","seykota","chart","volume","technical","combined")
METHODS = tuple(m.id for m in MODELS[9:])


def compute_facts(data, price, currency):
    values = data.get("values",{})
    previous = data.get("previous",{})
    def val(field, rows=values):
        row = rows.get(field)
        if row and row.get("unit") in (currency,currency+"/shares","shares"):
            return row.get("val")
        return None
    def ratio(a,b):
        return a/b if a is not None and b is not None and b>0 else None
    rev, past = val("revenue"), val("revenue",previous)
    equity, liabilities = val("equity"), val("liabilities")
    eps, shares = val("eps"), val("shares")
    ocf, capex = val("cashflow"),val("capex")
    fcf = ocf-capex if ocf is not None and capex is not None else None
    equity_per_share = ratio(equity,shares)
    return {"roe":ratio(val("net"),equity),"debt_equity":ratio(liabilities,equity),
            "margin":ratio(val("operating"),rev),"sales_growth":rev/past-1 if rev is not None and past and past>0 else None,
            "pe":ratio(price,eps),"pb":ratio(price,equity_per_share),"free_cashflow":fcf,
            "dividend_yield":ratio(val("dividend"),price)}


def direction(rule, positive, negative):
    return 1 if positive else (-1 if negative else 0)


def evaluate(bars, indicators, *, facts=None, news=None, community=None, macro=None):
    scores = dict.fromkeys(BY_ID)
    conditions = {}
    def add(name, value, reason):
        scores[name] = value
        conditions[name] = reason
    facts = facts or {}
    if bars:
        close = [b["close"] for b in bars]
        p = close[-1]
        move = pct(p,close[-2]) if len(close)>1 else None
        vol = indicators["vol_ratio"]
        trend = indicators["trend"]
        volatility = indicators["volatility"]
        rsi = indicators["rsi14"]
        if len(close)>=21:
            hi = max(b["high"] for b in bars[-21:-1])
            lo = min(b["low"] for b in bars[-21:-1])
            add("chart",direction("breakout",p>hi,p<lo),f"이전 고가 {hi:.6g}, 저가 {lo:.6g}")
            sd = stats.pstdev(close[-20:])
            z = (p-stats.fmean(close[-20:]))/sd if sd else 0
            add("simons",direction("z",z < -1.3,z > 1.3),f"20봉 표준점수 {z:.2f}")
            dd = pct(p,max(close[-20:]))
            add("marks",direction("drawdown",dd < -6 and rsi<45,dd>-1 and rsi>62),
                f"20봉 고점 대비 {dd:.2f}%, RSI {rsi:.1f}")
        if len(close)>=50:
            short,long = avg(close,20),avg(close,50)
            add("seykota",direction("trend",short>long,short<long),f"20/50봉 이동평균 {short:.6g} / {long:.6g}")
        if vol is not None and move is not None:
            add("volume",direction("volume",vol>=1.4 and move>0,vol>=1.4 and move<0),f"상대 거래량 {vol:.2f}배")
        h = indicators["macd_hist"]
        if h is not None and rsi is not None:
            add("technical",direction("momentum",h>0 and 48<=rsi<=72,h<0 or rsi>80),
                f"MACD 히스토그램 {h:.6g}, RSI {rsi:.1f}")
        if macro is not None and volatility is not None and trend is not None:
            add("dalio",direction("regime",trend>0 and volatility<3 and macro>=0,trend<0 and volatility>=3),
                f"추세 {trend:.2f}%, 변동성 {volatility:.2f}%, 금리차 {macro:.2f}%p")
        if community is not None and move is not None and vol is not None:
            add("soros",direction("reflexivity",move>0 and community>.2 and vol>=1.2,
                                  move<0 and community<-.2 and vol>=1.2),"가격·거래량·감성 방향 결합")
    for name,val in (("news",news),("community",community),("macro",macro)):
        if val is not None:
            add(name,direction(name,val>.2,val<-.2),f"최근 관측 점수 {val:.3f}")
    roe,debt,pe,pb,fcf,growth,margin = (facts.get(k) for k in
        ("roe","debt_equity","pe","pb","free_cashflow","sales_growth","margin"))
    if None not in (roe,fcf,pe):
        add("buffett",direction("quality",roe>.12 and fcf>0 and pe<24,roe<.05 or fcf<0),"ROE·잉여현금흐름·PER")
    if None not in (pe,pb,debt):
        add("graham",direction("value",pe<15 and pb<1.5 and debt<1,debt>2 or pe*pb>45),"PER·PBR·부채비율")
    if None not in (growth,pe,margin):
        add("lynch",direction("growth",growth>.08 and pe<=growth*120 and margin>0,growth<0 or margin<0),"매출 성장·PER·영업이익률")
    if None not in (roe,debt,margin):
        add("fundamental",direction("health",roe>.10 and debt<1.5 and margin>.08,roe<0 or debt>3),"ROE·부채비율·영업이익률")
    if growth is not None and scores["chart"] is not None and indicators["vol_ratio"] is not None:
        add("oneil",direction("growth breakout",growth>.15 and scores["chart"]==1 and indicators["vol_ratio"]>=1.4,
                             scores["chart"]==-1 or growth<0),"성장·돌파·거래량")
    consensus = [scores[m] for m in METHODS if m!="combined" and scores[m] is not None]
    active = set(consensus)-{0}
    conflict = len(active)>1
    if len(consensus)>=3:
        signal = 0 if conflict or sum(consensus)==0 else (1 if sum(consensus)>0 else -1)
        add("combined",signal,f"{len(consensus)}개 방법 가용 · 방향 {'충돌' if conflict else '합의 또는 중립'}")
    return scores,conditions,conflict
